@echo off
cd /d "%~dp0"
py -3 pz_localization_tool_pro.py || python pz_localization_tool_pro.py
echo.
pause
