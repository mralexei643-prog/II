@echo off
py -3 -m pip install --upgrade openpyxl || python -m pip install --upgrade openpyxl
pause
