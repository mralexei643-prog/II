@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade pyinstaller || python -m pip install --upgrade pyinstaller
py -3 -m PyInstaller --noconfirm --onefile --windowed --name PZ_Localization_Tool_Pro pz_localization_tool_pro.py || python -m PyInstaller --noconfirm --onefile --windowed --name PZ_Localization_Tool_Pro pz_localization_tool_pro.py
echo EXE: dist\PZ_Localization_Tool_Pro.exe
pause
