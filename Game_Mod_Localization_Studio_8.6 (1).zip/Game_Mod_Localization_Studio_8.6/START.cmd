@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (py -3 pz_localization_tool_pro.py) || (python pz_localization_tool_pro.py)
if errorlevel 1 (echo. & echo Startup failed. See startup_error.log & (py -3 pz_localization_tool_pro.py 2>startup_error.log || python pz_localization_tool_pro.py 2>startup_error.log) & pause)
