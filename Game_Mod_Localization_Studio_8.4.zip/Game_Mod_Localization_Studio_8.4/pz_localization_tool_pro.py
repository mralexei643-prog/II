#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import csv, hashlib, json, os, re, shutil, sys, tempfile, traceback, zipfile, difflib, threading, time, sqlite3, concurrent.futures
import urllib.request, urllib.error
import struct, zlib
import xml.etree.ElementTree as ET
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "Game Mod Localization Studio 8.4"
GAME_PZ = "Project Zomboid"
GAME_RW = "RimWorld"
SUPPORTED_EXTS = {".lua", ".txt", ".ini", ".cfg", ".json"}
SKIP_DIRS = {".git", ".svn", "node_modules", "translated_mods", "output", "backups", "__pycache__"}
STRING_RE = re.compile(r'(?P<quote>[\"\'])(?P<text>(?:\\.|(?!\1).)*?)(?P=quote)')
ENGLISH_RE = re.compile(r"[A-Za-z]{2,}")
URL_RE = re.compile(r"^(?:https?://|www\.)", re.I)
PATH_RE = re.compile(r"^(?:[A-Za-z]:[\\/]|media/|textures?/|sounds?/|scripts?/)", re.I)
IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.:/\\-]*$")
PLAYER_HINTS = tuple(x.lower() for x in (
    "getText(", "setTitle(", "setName(", "setTooltip(", "setDescription(", "addOption(",
    "addButton(", "addLabel(", "drawText(", "renderText(", "message", "tooltip", "description",
    "caption", "label", "title", "text", "DisplayName", "Tooltip", "ContextMenu", "UI_", "IGUI_", "Sandbox_"
))
FIELDS = ["id", "source_text", "translation", "file", "line", "context", "status", "protected", "occurrences"]
PROJECT_EXT = ".pzloc"
GLOSSARY_FILE = "glossary.json"
MEMORY_DB_FILE = "translation_memory.sqlite3"
SETTINGS_FILE = "settings.json"
PROJECT_LIBRARY_FILE = "project_library.json"


def normalize_memory_key(text: str):
    return re.sub(r"\s+", " ", text.strip().casefold())

PROFILE_TERMS = {
    "Общий": {},
    "Оружие": {"Magazine":"Магазин", "Round":"Патрон", "Ammo":"Боеприпасы", "Reload":"Перезарядить"},
    "Автомобили": {"Engine":"Двигатель", "Trunk":"Багажник", "Tire":"Шина", "Fuel":"Топливо"},
    "Медицина": {"Bandage":"Бинт", "Wound":"Рана", "Pain":"Боль", "Treatment":"Лечение"},
    "Строительство": {"Wall":"Стена", "Floor":"Пол", "Nails":"Гвозди", "Plank":"Доска"},
    "Интерфейс": {"Apply":"Применить", "Cancel":"Отмена", "Settings":"Настройки", "Confirm":"Подтвердить"},
}

class TranslationMemoryDB:
    def __init__(self, path: Path):
        self.path=path
        self._init()
    def connect(self):
        con=sqlite3.connect(self.path, timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        return con
    def _init(self):
        with self.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS translations(
                source TEXT PRIMARY KEY, normalized TEXT NOT NULL, translation TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'verified', category TEXT NOT NULL DEFAULT '',
                source_mod TEXT NOT NULL DEFAULT '', source_file TEXT NOT NULL DEFAULT '',
                use_count INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_tm_normalized ON translations(normalized)")
    def add_many(self, entries, source_mod=''):
        rows=[]; now=datetime.now().isoformat(timespec='seconds')
        for e in entries:
            t=e.translation.strip()
            if t and t != e.source_text.strip() and e.protected!='yes' and not validate_translation(e.source_text,t):
                rows.append((e.source_text,normalize_memory_key(e.source_text),t,'verified','',source_mod,e.file,now))
        if not rows:return 0
        with self.connect() as con:
            con.executemany("""INSERT INTO translations(source,normalized,translation,status,category,source_mod,source_file,updated_at)
              VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source) DO UPDATE SET translation=excluded.translation,
              normalized=excluded.normalized,status=excluded.status,source_mod=excluded.source_mod,
              source_file=excluded.source_file,use_count=translations.use_count+1,updated_at=excluded.updated_at""",rows)
        return len(rows)
    def lookup(self, text, allow_normalized=True):
        with self.connect() as con:
            row=con.execute("SELECT translation,status FROM translations WHERE source=?",(text,)).fetchone()
            if row:return row[0],'exact'
            if allow_normalized:
                rows=con.execute("SELECT translation,status FROM translations WHERE normalized=? ORDER BY status='verified' DESC,use_count DESC LIMIT 2",(normalize_memory_key(text),)).fetchall()
                if len(rows)==1:return rows[0][0],'normalized'
        return None,None
    def suggestions(self,text,limit=8):
        key=normalize_memory_key(text)
        with self.connect() as con:
            rows=con.execute("SELECT source,translation,status,use_count FROM translations ORDER BY use_count DESC LIMIT 1500").fetchall()
        scored=[]
        for src,tr,status,uses in rows:
            score=difflib.SequenceMatcher(None,key,normalize_memory_key(src)).ratio()
            if score>=0.55:scored.append((score,src,tr,status,uses))
        return sorted(scored,reverse=True)[:limit]
    def stats(self):
        with self.connect() as con:
            count=con.execute("SELECT COUNT(*) FROM translations").fetchone()[0]
            verified=con.execute("SELECT COUNT(*) FROM translations WHERE status='verified'").fetchone()[0]
        size=self.path.stat().st_size if self.path.exists() else 0
        return count,verified,size
    def export_json(self,path):
        with self.connect() as con:
            rows=con.execute("SELECT source,translation,status,category,source_mod,source_file,use_count,updated_at FROM translations ORDER BY source").fetchall()
        data=[dict(zip(('source','translation','status','category','source_mod','source_file','use_count','updated_at'),r)) for r in rows]
        Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    def import_data(self,data):
        now=datetime.now().isoformat(timespec='seconds'); rows=[]
        if isinstance(data,dict): data=[{'source':k,'translation':v} for k,v in data.items()]
        for x in data:
            src=str(x.get('source') or x.get('source_text') or '').strip(); tr=str(x.get('translation') or '').strip()
            if src and tr: rows.append((src,normalize_memory_key(src),tr,str(x.get('status','verified')),str(x.get('category','')),str(x.get('source_mod','')),str(x.get('source_file','')),now))
        with self.connect() as con:
            con.executemany("""INSERT INTO translations(source,normalized,translation,status,category,source_mod,source_file,updated_at) VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(source) DO UPDATE SET translation=excluded.translation,status=excluded.status,category=excluded.category,updated_at=excluded.updated_at""",rows)
        return len(rows)
    def clear(self):
        with self.connect() as con:con.execute('DELETE FROM translations')
    def put(self, source, translation, verified=True):
        source=str(source).strip(); translation=str(translation).strip()
        if not source or not translation:return False
        now=datetime.now().isoformat(timespec='seconds')
        with self.connect() as con:
            con.execute("""INSERT INTO translations(source,normalized,translation,status,updated_at) VALUES(?,?,?,?,?)
            ON CONFLICT(source) DO UPDATE SET normalized=excluded.normalized,translation=excluded.translation,status=excluded.status,updated_at=excluded.updated_at""",
            (source,normalize_memory_key(source),translation,'verified' if verified else 'draft',now))
        return True
    def search_rows(self, query='', limit=1000):
        query=str(query or '').strip(); limit=max(1,min(int(limit),5000))
        with self.connect() as con:
            if query:
                like=f"%{query}%"
                return con.execute("""SELECT source,translation,status,use_count,source_mod,updated_at FROM translations
                    WHERE source LIKE ? COLLATE NOCASE OR translation LIKE ? COLLATE NOCASE
                    ORDER BY use_count DESC, updated_at DESC LIMIT ?""",(like,like,limit)).fetchall()
            return con.execute("""SELECT source,translation,status,use_count,source_mod,updated_at FROM translations
                ORDER BY updated_at DESC LIMIT ?""",(limit,)).fetchall()
    def update_row(self, old_source, source, translation, status='verified'):
        source=str(source).strip(); translation=str(translation).strip()
        if not source or not translation:raise ValueError('Оригинал и перевод не могут быть пустыми.')
        now=datetime.now().isoformat(timespec='seconds')
        with self.connect() as con:
            if old_source != source:con.execute('DELETE FROM translations WHERE source=?',(old_source,))
            con.execute("""INSERT INTO translations(source,normalized,translation,status,updated_at) VALUES(?,?,?,?,?)
                ON CONFLICT(source) DO UPDATE SET normalized=excluded.normalized,translation=excluded.translation,status=excluded.status,updated_at=excluded.updated_at""",
                (source,normalize_memory_key(source),translation,status,now))
    def delete_rows(self, sources):
        sources=[str(x) for x in sources if str(x)]
        if not sources:return 0
        with self.connect() as con:con.executemany('DELETE FROM translations WHERE source=?',[(x,) for x in sources])
        return len(sources)
    def optimize(self):
        with self.connect() as con:
            con.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            con.execute('VACUUM')
            con.execute('ANALYZE')


@dataclass
class Entry:
    id: str
    source_text: str
    translation: str
    file: str
    line: int
    context: str
    status: str = "not_translated"
    protected: str = "no"
    occurrences: int = 1


def decode_bytes(data: bytes):
    # Preserve the original BOM state. Trying utf-8-sig first for every UTF-8 file
    # would add a BOM when the file is written back.
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig"), "utf-8-sig"
    for enc in ("utf-8", "cp1251", "latin-1"):
        try: return data.decode(enc), enc
        except UnicodeDecodeError: pass
    return data.decode("utf-8", errors="replace"), "utf-8"

def encode_text(text: str, enc: str):
    try: return text.encode(enc)
    except Exception: return text.encode("utf-8")

def normalize_literal(raw: str):
    """Decode common quoted-string escapes without corrupting unknown Lua escapes."""
    out = []
    i = 0
    escapes = {"n": "\n", "r": "\r", "t": "\t", "\\": "\\", '"': '"', "'": "'"}
    while i < len(raw):
        ch = raw[i]
        if ch == "\\" and i + 1 < len(raw):
            nxt = raw[i + 1]
            if nxt in escapes:
                out.append(escapes[nxt])
                i += 2
                continue
            out.extend(("\\", nxt))
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)

def escape_literal(value: str, quote: str):
    value = value.replace("\\", "\\\\").replace("\r", r"\r").replace("\n", r"\n").replace("\t", r"\t")
    return value.replace(quote, "\\" + quote)

def entry_id(text: str): return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]

def technical_reason(s: str, line: str):
    low = line.lower()
    hinted = any(h in low for h in PLAYER_HINTS)
    if URL_RE.search(s): return "URL"
    if PATH_RE.search(s): return "path"
    if re.fullmatch(r"[A-Fa-f0-9]{8,}", s): return "hash"
    if s.startswith(("$", "@")) and " " not in s: return "token"
    if IDENT_RE.fullmatch(s) and ("_" in s or "." in s or "/" in s or "\\" in s or ":" in s) and not hinted: return "identifier"
    if re.fullmatch(r"[A-Z0-9_]{3,}", s) and not hinted: return "constant"
    return ""

def is_candidate(text: str):
    s = text.strip()
    return 2 <= len(s) <= 1500 and bool(ENGLISH_RE.search(s))

def iter_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS and not any(part in SKIP_DIRS for part in p.parts):
            yield p

def extract_entries(root: Path):
    found, counts = {}, {}
    for path in iter_files(root):
        rel = path.relative_to(root).as_posix()
        text, _ = decode_bytes(path.read_bytes())
        for lineno, line in enumerate(text.splitlines(), 1):
            if line.strip().startswith(("--", "//")): continue
            for m in STRING_RE.finditer(line):
                value = normalize_literal(m.group("text")).strip()
                if not is_candidate(value): continue
                counts[value] = counts.get(value, 0) + 1
                if value not in found:
                    reason = technical_reason(value, line)
                    context = line.strip()[:500]
                    found[value] = Entry(entry_id(value), value, "", rel, lineno, context,
                                         "protected" if reason else "not_translated", "yes" if reason else "no", 1)
    entries = sorted(found.values(), key=lambda e:(e.protected=="yes", e.file.lower(), e.line, e.source_text.lower()))
    for e in entries: e.occurrences = counts[e.source_text]
    return entries


RW_TRANSLATABLE_TAGS = {
    "label", "labelShort", "description", "jobString", "reportString", "gerund",
    "inspectString", "customLabel", "text", "message", "title", "verb", "beginLetter"
}

def _xml_text_candidate(value: str):
    value=(value or "").strip()
    return value if is_candidate(value) else ""

def extract_rimworld_entries(root: Path):
    """Extract RimWorld Keyed, DefInjected candidates and Strings without changing source files."""
    found, counts = {}, {}
    def add(value, rel, line, context):
        value=(value or "").strip()
        if not is_candidate(value): return
        counts[value]=counts.get(value,0)+1
        if value not in found:
            found[value]=Entry(entry_id(value),value,"",rel,line,context,"not_translated","no",1)

    # Existing English localization is the most authoritative source.
    for lang in root.rglob("Languages"):
        eng=lang/"English"
        if not eng.is_dir(): continue
        for path in eng.rglob("*"):
            if not path.is_file(): continue
            rel=path.relative_to(root).as_posix()
            if path.suffix.lower()==".xml":
                try:
                    tree=ET.parse(path)
                    for elem in tree.getroot().iter():
                        if len(elem)==0 and _xml_text_candidate(elem.text):
                            add(elem.text,rel,0,f"RW_KEYED|{path.relative_to(eng).as_posix()}|{elem.tag}")
                except ET.ParseError:
                    continue
            elif "Strings" in path.parts:
                text,_=decode_bytes(path.read_bytes())
                for n,line in enumerate(text.splitlines(),1):
                    if _xml_text_candidate(line): add(line,rel,n,f"RW_STRING|{path.relative_to(eng).as_posix()}")

    # Generate DefInjected candidates from Defs when English localization is absent/incomplete.
    for defs in root.rglob("Defs"):
        if not defs.is_dir(): continue
        for path in defs.rglob("*.xml"):
            rel=path.relative_to(root).as_posix()
            try: root_el=ET.parse(path).getroot()
            except ET.ParseError: continue
            for def_el in list(root_el):
                def_name=def_el.findtext("defName")
                if not def_name: continue
                def_type=def_el.tag
                for child in list(def_el):
                    if child.tag in RW_TRANSLATABLE_TAGS and len(child)==0 and _xml_text_candidate(child.text):
                        add(child.text,rel,0,f"RW_DEF|{def_type}|{def_name}|{child.tag}|{path.name}")
    entries=sorted(found.values(),key=lambda e:(e.file.lower(),e.line,e.source_text.lower()))
    for e in entries:e.occurrences=counts[e.source_text]
    return entries

def detect_game_structure(root: Path):
    pz=sum(1 for _ in root.rglob("mod.info")) + sum(1 for _ in root.rglob("media"))
    rw=sum(1 for _ in root.rglob("About.xml")) + sum(1 for _ in root.rglob("Defs")) + sum(1 for _ in root.rglob("Languages"))
    if rw>pz and rw>0:return GAME_RW
    if pz>0:return GAME_PZ
    return ""

def xml_indent(elem, level=0):
    pad="\n"+"  "*level
    if len(elem):
        if not elem.text or not elem.text.strip():elem.text=pad+"  "
        for child in elem:
            xml_indent(child,level+1)
            if not child.tail or not child.tail.strip():child.tail=pad+"  "
        if not elem[-1].tail or not elem[-1].tail.strip():elem[-1].tail=pad

def build_rimworld_translation(root: Path, out: Path, entries, mod_name: str):
    trans=translation_map(entries)
    if not trans: raise ValueError("Нет заполненных переводов")
    safe=safe_mod_name(mod_name or root.name)
    package=out/f"{safe}_Russian"
    if package.exists():shutil.rmtree(package)
    (package/"About").mkdir(parents=True)
    langs=package/"Languages"/"Russian"
    langs.mkdir(parents=True)
    groups={}; strings={}; replacements=0
    for e in entries:
        tr=trans.get(e.source_text)
        if not tr:continue
        parts=e.context.split("|")
        if parts[0]=="RW_DEF" and len(parts)>=5:
            _,dtype,dname,tag,srcname=parts[:5]
            key=f"{dname}.{tag}"
            groups.setdefault(("DefInjected",dtype,srcname),{})[key]=tr;replacements+=1
        elif parts[0]=="RW_KEYED" and len(parts)>=3:
            _,rel,key=parts[0],parts[1],parts[2]
            rel_path=rel[6:] if rel.startswith("Keyed/") else rel
            groups.setdefault(("Keyed","",rel_path),{})[key]=tr;replacements+=1
        elif parts[0]=="RW_STRING" and len(parts)>=2:
            strings.setdefault(parts[1],{})[e.source_text]=tr;replacements+=1
    for (kind,dtype,name),items in groups.items():
        target=(langs/kind/(dtype if dtype else "" )/name)
        target.parent.mkdir(parents=True,exist_ok=True)
        root_el=ET.Element("LanguageData")
        for key,val in sorted(items.items()):ET.SubElement(root_el,key).text=val
        xml_indent(root_el);ET.ElementTree(root_el).write(target,encoding="utf-8",xml_declaration=True)
    # Recreate translated Strings files from the original English files.
    for rel,mapping in strings.items():
        candidates=list(root.rglob("Languages/English/"+rel))
        if not candidates:continue
        text,enc=decode_bytes(candidates[0].read_bytes())
        for src,tr in mapping.items():text=text.replace(src,tr)
        target=langs/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encode_text(text,enc))
    about_name=f"{mod_name or root.name} — Russian Translation"
    package_id=f"local.translation.{safe.lower()}"
    about=ET.Element("ModMetaData")
    ET.SubElement(about,"name").text=about_name
    ET.SubElement(about,"author").text="Generated by Game Mod Localization Studio"
    ET.SubElement(about,"packageId").text=package_id
    ET.SubElement(about,"description").text=f"Русский перевод для {mod_name or root.name}. Загрузите после оригинального мода."
    xml_indent(about);ET.ElementTree(about).write(package/"About"/"About.xml",encoding="utf-8",xml_declaration=True)
    readme=("УСТАНОВКА ПЕРЕВОДА RIMWORLD\n==========================\n\n"
            "Поместите папку мода в RimWorld/Mods и включите её после оригинального мода.\n"
            f"Переведено строк: {replacements}\n")
    (package/"README_УСТАНОВКА.txt").write_text(readme,encoding="utf-8")
    zp=out/f"{safe}_Russian_RimWorld.zip"
    if zp.exists():zp.unlink()
    zip_folder(package,zp)
    return package,zp,replacements


def write_csv(entries, path):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f, fieldnames=FIELDS, delimiter=";"); w.writeheader(); w.writerows(asdict(e) for e in entries)

def write_json(entries, path): path.write_text(json.dumps([asdict(e) for e in entries], ensure_ascii=False, indent=2), encoding="utf-8")

def write_xlsx(entries, path):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.table import Table, TableStyleInfo
        wb=Workbook(); ws=wb.active; ws.title="Translations"; ws.append(FIELDS)
        for e in entries: ws.append([getattr(e,k) for k in FIELDS])
        for c in ws[1]: c.font=Font(bold=True); c.fill=PatternFill("solid", fgColor="D9EAF7")
        for col,w in {"A":15,"B":48,"C":48,"D":50,"E":9,"F":70,"G":18,"H":12,"I":12}.items(): ws.column_dimensions[col].width=w
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        if ws.max_row>1:
            t=Table(displayName="TranslationsTable",ref=f"A1:I{ws.max_row}"); t.tableStyleInfo=TableStyleInfo(name="TableStyleMedium2",showRowStripes=True); ws.add_table(t)
        for row in ws.iter_rows(min_row=2,min_col=2,max_col=6):
            for c in row: c.alignment=Alignment(vertical="top",wrap_text=True)
        wb.save(path); return True,""
    except Exception as e: return False,str(e)

def load_rows(path: Path):
    ext=path.suffix.lower(); rows=[]
    if ext==".csv":
        text,_=decode_bytes(path.read_bytes()); delim=";" if text[:4096].count(";")>=text[:4096].count(",") else ","; rows=list(csv.DictReader(text.splitlines(),delimiter=delim))
    elif ext==".json": rows=json.loads(path.read_text(encoding="utf-8-sig"))
    elif ext==".xlsx":
        from openpyxl import load_workbook
        wb=load_workbook(path,read_only=True,data_only=True); ws=wb.active; hdr=[str(x or "") for x in next(ws.iter_rows(values_only=True))]
        rows=[dict(zip(hdr,r)) for r in ws.iter_rows(min_row=2,values_only=True)]
    else: raise ValueError("Поддерживаются CSV, XLSX и JSON")
    result=[]
    for r in rows:
        data={k:str(r.get(k,"") if r.get(k,"") is not None else "") for k in FIELDS}
        try: data["line"]=int(float(data["line"] or 0))
        except: data["line"]=0
        try: data["occurrences"]=int(float(data["occurrences"] or 1))
        except: data["occurrences"]=1
        if not data["id"] and data["source_text"]: data["id"]=entry_id(data["source_text"])
        if not data["status"]: data["status"]="translated" if data["translation"].strip() else "not_translated"
        if not data["protected"]: data["protected"]="no"
        result.append(Entry(**data))
    return result

def backup(path: Path, backup_dir: Path):
    if path.exists():
        backup_dir.mkdir(parents=True,exist_ok=True); stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); shutil.copy2(path, backup_dir/f"{path.stem}_{stamp}{path.suffix}")

def prepare_source(source: Path, temp: Path):
    if source.is_dir():
        return source
    if source.suffix.lower() == ".zip":
        temp_resolved = temp.resolve()
        with zipfile.ZipFile(source) as z:
            for member in z.infolist():
                target = (temp / member.filename).resolve()
                try:
                    target.relative_to(temp_resolved)
                except ValueError:
                    raise ValueError(f"Небезопасный путь внутри ZIP: {member.filename}")
            z.extractall(temp)
        return temp
    raise ValueError("Выберите папку или ZIP")

def translation_map(entries):
    return {e.source_text:e.translation.strip() for e in entries if e.translation.strip() and e.translation.strip()!=e.source_text and e.protected!="yes"}

PLACEHOLDER_PATTERNS = (
    r"%(?:\d+\$)?[-+#0 ]*(?:\d+|\*)?(?:\.(?:\d+|\*))?[a-zA-Z%]",
    r"\{[^{}\n]+\}",
    r"<[^<>\n]+>",
    r"\$\{[^{}\n]+\}",
    r"\[[A-Z][A-Z0-9_:-]*\]",
)

def placeholder_tokens(text: str):
    tokens=[]
    for pattern in PLACEHOLDER_PATTERNS:
        tokens.extend(re.findall(pattern,text))
    return sorted(tokens)

def validate_translation(src,tgt):
    issues=[]
    src_tokens=placeholder_tokens(src); tgt_tokens=placeholder_tokens(tgt)
    if src_tokens != tgt_tokens:
        missing=list(src_tokens)
        for token in tgt_tokens:
            if token in missing: missing.remove(token)
        extra=list(tgt_tokens)
        for token in src_tokens:
            if token in extra: extra.remove(token)
        if missing: issues.append("потеряны: "+", ".join(missing[:8]))
        if extra: issues.append("лишние: "+", ".join(extra[:8]))
    if tgt.count("\n")!=src.count("\n"): issues.append("изменены переносы строк")
    if src.count("\\n")!=tgt.count("\\n"): issues.append("изменены \\n")
    if src.count("\t")!=tgt.count("\t"): issues.append("изменены табуляции")
    return "; ".join(issues)


def entry_issue(entry):
    """QA issue for an entry, respecting a deliberate user override."""
    if entry.protected == "yes" or entry.status == "accepted":
        return ""
    return validate_translation(entry.source_text, entry.translation) if entry.translation else ""

def preserve_outer_whitespace(raw_value: str, translated: str):
    left_len = len(raw_value) - len(raw_value.lstrip())
    right_len = len(raw_value) - len(raw_value.rstrip())
    left = raw_value[:left_len]
    right = raw_value[len(raw_value) - right_len:] if right_len else ""
    return left + translated + right


def apply_translations(root,out_root,translations):
    if out_root.exists(): shutil.rmtree(out_root)
    shutil.copytree(root,out_root); changed=repl_count=0
    for path in iter_files(out_root):
        text,enc=decode_bytes(path.read_bytes()); original=text
        def repl(m):
            nonlocal repl_count
            raw = normalize_literal(m.group("text"))
            src = raw.strip(); target=translations.get(src)
            if not target:return m.group(0)
            repl_count+=1; q=m.group("quote")
            return q+escape_literal(preserve_outer_whitespace(raw, target),q)+q
        text=STRING_RE.sub(repl,text)
        if text!=original: path.write_bytes(encode_text(text,enc)); changed+=1
    return changed,repl_count

def zip_folder(folder,zip_path):
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in folder.rglob("*"):
            if p.is_file(): z.write(p,p.relative_to(folder))


def safe_mod_name(value: str):
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    return value.strip("_.-") or "TranslatedMod"


def find_mod_roots(root: Path):
    roots = sorted({p.parent for p in root.rglob("mod.info") if p.is_file()}, key=lambda x: len(x.parts))
    if roots:
        return roots
    # Fallback for archives without mod.info: treat every directory that directly
    # contains a media folder as a mod root.
    roots = sorted({p.parent for p in root.rglob("media") if p.is_dir()}, key=lambda x: len(x.parts))
    return roots or [root]


def apply_translations_to_patch(mod_root: Path, patch_root: Path, translations):
    changed = repl_count = 0
    changed_files = []
    for src_path in iter_files(mod_root):
        text, enc = decode_bytes(src_path.read_bytes())
        original = text
        local_repls = 0
        def repl(m):
            nonlocal repl_count, local_repls
            raw = normalize_literal(m.group("text"))
            src = raw.strip()
            target = translations.get(src)
            if not target:
                return m.group(0)
            repl_count += 1
            local_repls += 1
            q = m.group("quote")
            return q + escape_literal(preserve_outer_whitespace(raw, target), q) + q
        text = STRING_RE.sub(repl, text)
        if text != original:
            dst = patch_root / src_path.relative_to(mod_root)
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(encode_text(text, enc))
            changed += 1
            changed_files.append(dst.relative_to(patch_root).as_posix())
    return changed, repl_count, changed_files


def zip_contents(folder: Path, zip_path: Path):
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in folder.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(folder))






def detect_mod_layout(mod_root: Path):
    """Return (package_root, content_relative_path) for B41/B42 mod layouts.

    Build 41 usually stores mod.info directly in the mod folder. Build 42 mods
    commonly store it in a version directory such as 42, 42.13 or 42.16.
    The generated translation mirrors that layout so the folder can be copied
    directly into Zomboid/mods.
    """
    if re.fullmatch(r"42(?:\.\d+)*", mod_root.name, flags=re.I):
        return mod_root.parent, Path(mod_root.name)
    return mod_root, Path()

def copy_poster_for_layout(mod_root: Path, content_root: Path):
    return create_translation_poster(mod_root, content_root)

def read_mod_info(mod_root: Path):
    info_path=mod_root/"mod.info"
    data={}
    if info_path.exists():
        text,_=decode_bytes(info_path.read_bytes())
        for line in text.splitlines():
            if "=" in line and not line.lstrip().startswith(("#",";")):
                k,v=line.split("=",1); data[k.strip().lower()]=v.strip()
    return data


def unique_safe_id(value: str):
    value=re.sub(r"[^A-Za-z0-9_.-]+","_",value).strip("_.-")
    return value or "UnknownMod"


def write_simple_ukraine_poster(path: Path, title: str):
    """Create a valid 512x512 PNG without external dependencies."""
    width=height=512
    # Ukrainian flag background: blue top, yellow bottom.
    rows=[]
    for y in range(height):
        rgb=(0,87,184) if y < height//2 else (255,215,0)
        rows.append(b"\x00" + bytes(rgb)*width)
    raw=b"".join(rows)
    def chunk(kind,data):
        return struct.pack(">I",len(data))+kind+data+struct.pack(">I",zlib.crc32(kind+data)&0xffffffff)
    png=b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",width,height,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(raw,9))+chunk(b"IEND",b"")
    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(png)


def create_translation_poster(mod_root: Path, patch_root: Path):
    candidates=[]
    info=read_mod_info(mod_root)
    poster_name=info.get("poster","")
    if poster_name: candidates.append(mod_root/poster_name)
    candidates += [mod_root/"poster.png",mod_root/"poster.jpg",mod_root/"poster.jpeg"]
    candidates += list(mod_root.glob("*.png")) + list(mod_root.glob("*.jpg"))
    for candidate in candidates:
        if candidate.is_file():
            try:
                name="poster"+candidate.suffix.lower()
                shutil.copy2(candidate,patch_root/name)
                return name
            except Exception: pass
    write_simple_ukraine_poster(patch_root/"poster.png",mod_root.name)
    return "poster.png"


def count_scripts_and_languages(root: Path):
    """Conservative source analysis. It never claims that a mod needs no translation
    merely because no simple quoted English strings were found."""
    total_files = text_files = candidate_strings = english_strings = cyrillic_strings = 0
    ru_paths = 0; parse_errors=[]; extensions={}
    for path in root.rglob("*"):
        if not path.is_file() or any(part in SKIP_DIRS for part in path.parts):
            continue
        total_files += 1
        ext=path.suffix.lower(); extensions[ext]=extensions.get(ext,0)+1
        low=path.as_posix().lower()
        if any(x in low for x in ("/translate/ru/", "/translations/ru/", "_ru.", "/ru/")):
            ru_paths += 1
        if ext not in SUPPORTED_EXTS:
            continue
        text_files += 1
        try: text,_=decode_bytes(path.read_bytes())
        except Exception as exc:
            parse_errors.append(f"{path.name}: {exc}"); continue
        for line in text.splitlines():
            if line.strip().startswith(("--","//")): continue
            for m in STRING_RE.finditer(line):
                value=normalize_literal(m.group("text")).strip()
                if len(value)<2: continue
                has_en=bool(re.search(r"[A-Za-z]{2,}",value))
                has_ru=bool(re.search(r"[А-Яа-яЁёІіЇїЄє]{2,}",value))
                if has_en or has_ru: candidate_strings += 1
                if has_en and not technical_reason(value,line): english_strings += 1
                if has_ru: cyrillic_strings += 1
    if parse_errors:
        status="Нужна ручная проверка"; confidence="низкая"
        reason="Некоторые файлы не удалось прочитать."
    elif english_strings>0:
        status="Перевод требуется"; confidence="высокая"
        reason=f"Найдено потенциально видимых английских строк: {english_strings}."
    elif cyrillic_strings>0 or ru_paths>0:
        status="Перевод уже присутствует"; confidence="средняя"
        reason=f"Найдены кириллические строки ({cyrillic_strings}) или русские каталоги локализации ({ru_paths})."
    elif candidate_strings==0:
        status="Локализуемый текст не найден"; confidence="средняя"
        reason="В поддерживаемых текстовых файлах не найдено обычных строк для перевода. Текст может создаваться программно."
    else:
        status="Вероятно, перевод не требуется"; confidence="низкая"
        reason="Английские пользовательские строки не обнаружены, но структура мода может быть нестандартной."
    return {"status":status,"confidence":confidence,"reason":reason,"total_files":total_files,
            "text_files":text_files,"candidate_strings":candidate_strings,"english_strings":english_strings,
            "cyrillic_strings":cyrillic_strings,"ru_paths":ru_paths,"parse_errors":parse_errors[:20],"extensions":extensions}


def safe_extract_zip(zip_path: Path, destination: Path):
    destination.mkdir(parents=True,exist_ok=True); base=destination.resolve()
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            target=(destination/member.filename).resolve()
            try: target.relative_to(base)
            except ValueError: raise ValueError(f"Небезопасный путь внутри ZIP: {member.filename}")
        z.extractall(destination)
    return destination


def discover_translation_mods(root: Path):
    roots=[]
    for info in root.rglob('mod.info'):
        if not info.is_file(): continue
        mod_root=info.parent
        package_root=mod_root.parent if re.fullmatch(r"42(?:\.\d+)*",mod_root.name,re.I) else mod_root
        if package_root not in roots: roots.append(package_root)
    return sorted(roots,key=lambda x:x.as_posix().lower())


def merge_translation_packages(inputs, output_dir: Path, pack_name: str, pack_id: str):
    """Merge already generated translation mods into one translation mod.
    Source packages are never modified. Different bytes at the same destination
    are reported as blocking conflicts instead of being overwritten."""
    output_dir.mkdir(parents=True,exist_ok=True)
    work=output_dir/(safe_mod_name(pack_id)+'_work')
    if work.exists(): shutil.rmtree(work)
    work.mkdir(parents=True)
    combined=work/safe_mod_name(pack_id)
    combined.mkdir()
    conflicts=[]; warnings=[]; copied=0; requires=[]; sources=[]; version_dirs=set()
    with tempfile.TemporaryDirectory(prefix='pzloc_merge_') as td:
        temp=Path(td)
        all_roots=[]
        for i,raw in enumerate(inputs):
            src=Path(raw)
            if not src.exists(): warnings.append(f"Не найден источник: {src}"); continue
            root=safe_extract_zip(src,temp/f'in_{i}') if src.is_file() and src.suffix.lower()=='.zip' else src
            mods=discover_translation_mods(root)
            if not mods: warnings.append(f"В {src.name} не найдены mod.info"); continue
            all_roots.extend(mods)
        for mod_root in all_roots:
            info_candidates=list(mod_root.glob('mod.info'))+list(mod_root.glob('42*/mod.info'))
            info={}
            for ip in info_candidates:
                info.update(read_mod_info(ip.parent))
            req=info.get('require','').strip()
            for item in re.split(r'[,;]',req):
                item=item.strip()
                if item and item not in requires: requires.append(item)
            sources.append(info.get('name') or mod_root.name)
            for src_file in mod_root.rglob('*'):
                if not src_file.is_file(): continue
                rel=src_file.relative_to(mod_root)
                if src_file.name.lower() in ('mod.info','poster.png','poster.jpg','poster.jpeg'):
                    continue
                if rel.parts and re.fullmatch(r"42(?:\.\d+)*",rel.parts[0],re.I): version_dirs.add(rel.parts[0])
                dst=combined/rel
                if dst.exists():
                    if hashlib.sha256(dst.read_bytes()).digest()!=hashlib.sha256(src_file.read_bytes()).digest():
                        conflicts.append(rel.as_posix())
                    continue
                dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src_file,dst); copied+=1
    conflicts=sorted(set(conflicts))
    if conflicts:
        shutil.rmtree(work,ignore_errors=True)
        return {"ok":False,"conflicts":conflicts,"warnings":warnings,"copied":copied,"requires":requires,"sources":sources}
    description='Общий русский перевод: '+', '.join(sources[:20])
    req_line=','.join(requires)
    info_text=(f"name={pack_name}\n"
               f"id={unique_safe_id(pack_id)}\n"
               f"description={description}\n"
               "poster=poster.png\n")
    if req_line: info_text+=f"require={req_line}\n"
    (combined/'mod.info').write_text(info_text,encoding='utf-8')
    write_simple_ukraine_poster(combined/'poster.png',pack_name)
    for version in sorted(version_dirs):
        vr=combined/version; vr.mkdir(parents=True,exist_ok=True)
        (vr/'mod.info').write_text(info_text,encoding='utf-8')
        if not (vr/'poster.png').exists(): shutil.copy2(combined/'poster.png',vr/'poster.png')
    zip_path=output_dir/(safe_mod_name(pack_id)+'.zip')
    if zip_path.exists(): zip_path.unlink()
    zip_contents(work,zip_path)
    shutil.rmtree(work,ignore_errors=True)
    return {"ok":True,"zip":str(zip_path),"conflicts":[],"warnings":warnings,"copied":copied,"requires":requires,"sources":sources,"versions":sorted(version_dirs)}

def parse_json_object(text: str):
    text=text.strip()
    text=re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I|re.S).strip()
    start=text.find("{"); end=text.rfind("}")
    if start<0 or end<start: raise ValueError("ИИ не вернул JSON-объект")
    obj=json.loads(text[start:end+1])
    if not isinstance(obj,dict): raise ValueError("Ожидался JSON-объект")
    return {str(k):str(v) for k,v in obj.items()}

def http_json(url, payload, headers=None, timeout=180):
    data=json.dumps(payload,ensure_ascii=False).encode("utf-8")
    req=urllib.request.Request(url,data=data,headers={"Content-Type":"application/json",**(headers or {})},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body=e.read().decode("utf-8",errors="replace")
        raise RuntimeError(f"HTTP {e.code}: {body[:1200]}")

def text_language_stats(text):
    """Return counts used to avoid exporting strings that are already Russian."""
    text=str(text or "")
    cyr=sum(1 for ch in text if "А" <= ch <= "я" or ch in "ЁёІіЇїЄєҐґ")
    lat=sum(1 for ch in text if ("A" <= ch <= "Z") or ("a" <= ch <= "z"))
    letters=cyr+lat
    return cyr,lat,letters


def is_probably_already_russian(text, threshold=0.70):
    """Pure/mostly Cyrillic user-facing text is treated as already translated.
    Mixed Latin+Cyrillic strings remain exportable so partial translations can be fixed.
    """
    cyr,lat,letters=text_language_stats(text)
    if letters < 2:
        return False
    return cyr / letters >= threshold and lat <= max(2, int(letters * 0.12))


def chatgpt_export_candidates(entries):
    pending=[]; skipped_russian=[]; skipped_existing=[]; skipped_protected=[]
    seen=set()
    for e in entries:
        if e.protected == "yes":
            skipped_protected.append(e); continue
        if e.translation.strip():
            skipped_existing.append(e); continue
        if is_probably_already_russian(e.source_text):
            skipped_russian.append(e); continue
        # Entries are normally deduplicated by extraction, but keep export safe.
        key=e.source_text.strip()
        if key in seen:
            continue
        seen.add(key); pending.append(e)
    return pending,skipped_russian,skipped_existing,skipped_protected

def ai_prompt(items, glossary):
    rules="\n".join(f"- {k} => {v}" for k,v in list(glossary.items())[:200])
    payload={str(i):text for i,text in items}
    return f"""Translate game mod UI/dialogue text from English into natural Russian. Preserve all placeholders, XML/formatting tags and technical identifiers exactly.
Return ONLY one valid JSON object with exactly the same numeric keys.
Input values may be strings or objects containing a "text" field and context metadata.
Translate only the source text. Every output key must map directly to one translated string, never to an object.
Preserve placeholders exactly: %s, %d, {{name}}, <br>, \n escapes, color tags, and technical tokens.
Do not translate NPC, XP, UI identifiers, file paths, URLs, or code.
Keep tone concise and suitable for a survival game.
Glossary:
{rules}

INPUT JSON:
{json.dumps(payload,ensure_ascii=False)}"""

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title(APP_TITLE); self.geometry("1420x860"); self.minsize(1120,700)
        self.entries=[]; self.visible=[]; self.current=None; self.dirty=False; self.project_path=None; self.glossary=self.load_glossary()
        self.settings=self.load_settings(); self.theme_dark=bool(self.settings.get("theme_dark",True)); self.tmdb=TranslationMemoryDB(Path.cwd()/MEMORY_DB_FILE)
        self.ai_cancel=False; self.ai_running=False; self.merge_chatgpt_batches=tk.BooleanVar(value=True)
        self.game=tk.StringVar(value=self.settings.get("last_game",GAME_PZ))
        self.source=tk.StringVar(); self.table=tk.StringVar(value=str(Path.cwd()/"translations.csv")); self.output=tk.StringVar(value=str(Path.cwd()/"output"))
        self.search=tk.StringVar(); self.filter=tk.StringVar(value="Все"); self.status=tk.StringVar(value="Готово")
        self._ui(); self.on_game_changed(); self._install_clipboard_shortcuts(); self.protocol("WM_DELETE_WINDOW",self.on_close)
        default=Path(self.table.get());
        if default.exists(): self.load_table(default)

    def _install_clipboard_shortcuts(self):
        """Ctrl+C/Ctrl+V/Ctrl+X/Ctrl+A во всех текстовых полях и копирование строк таблиц."""
        text_classes=("Text", "Entry", "TEntry", "TSpinbox", "TCombobox")

        def widget_state(widget):
            try: return str(widget.cget("state"))
            except Exception: return "normal"

        def virtual(event, name, *, writable=False):
            try:
                if writable and widget_state(event.widget) in ("disabled", "readonly"):
                    return "break"
                event.widget.event_generate(name)
            except Exception:
                pass
            return "break"

        def select_all(event):
            w=event.widget
            try:
                if isinstance(w, tk.Text):
                    w.tag_add("sel", "1.0", "end-1c"); w.mark_set("insert", "end-1c"); w.see("insert")
                else:
                    w.selection_range(0, "end"); w.icursor("end")
            except Exception:
                pass
            return "break"

        def copy_tree(event):
            tree=event.widget
            try:
                selected=tree.selection()
                if not selected:
                    row=tree.identify_row(event.y) if hasattr(event, "y") else ""
                    if row: selected=(row,)
                lines=[]
                for item in selected:
                    values=tree.item(item, "values")
                    if values: lines.append("\t".join(str(v) for v in values))
                    else:
                        text=tree.item(item, "text")
                        if text: lines.append(str(text))
                if lines:
                    self.clipboard_clear(); self.clipboard_append("\n".join(lines)); self.update_idletasks()
            except Exception:
                pass
            return "break"

        for cls in text_classes:
            for sequence in ("<Control-c>", "<Control-C>"):
                self.bind_class(cls, sequence, lambda e: virtual(e, "<<Copy>>"), add="+")
            for sequence in ("<Control-v>", "<Control-V>", "<Shift-Insert>"):
                self.bind_class(cls, sequence, lambda e: virtual(e, "<<Paste>>", writable=True), add="+")
            for sequence in ("<Control-x>", "<Control-X>"):
                self.bind_class(cls, sequence, lambda e: virtual(e, "<<Cut>>", writable=True), add="+")
            for sequence in ("<Control-a>", "<Control-A>"):
                self.bind_class(cls, sequence, select_all, add="+")

        for sequence in ("<Control-c>", "<Control-C>"):
            self.bind_class("Treeview", sequence, copy_tree, add="+")

        def popup_menu(event):
            w=event.widget
            cls=w.winfo_class()
            if cls not in text_classes and cls != "Treeview": return
            menu=tk.Menu(w, tearoff=False)
            if cls == "Treeview":
                menu.add_command(label="Копировать строку", command=lambda:copy_tree(event))
            else:
                menu.add_command(label="Вырезать", command=lambda:w.event_generate("<<Cut>>"), state=("disabled" if widget_state(w) in ("disabled","readonly") else "normal"))
                menu.add_command(label="Копировать", command=lambda:w.event_generate("<<Copy>>"))
                menu.add_command(label="Вставить", command=lambda:w.event_generate("<<Paste>>"), state=("disabled" if widget_state(w) in ("disabled","readonly") else "normal"))
                menu.add_separator(); menu.add_command(label="Выделить всё", command=lambda:select_all(type("E",(),{"widget":w})()))
            try: menu.tk_popup(event.x_root,event.y_root)
            finally: menu.grab_release()
            return "break"

        self.bind_all("<Button-3>", popup_menu, add="+")

    def _configure_styles(self):
        self.colors = {
            "bg": "#111827", "panel": "#182235", "panel2": "#202c42",
            "field": "#0f172a", "text": "#f3f4f6", "muted": "#9ca3af",
            "accent": "#3b82f6", "accent_hover": "#2563eb", "good": "#22c55e",
            "warn": "#f59e0b", "bad": "#ef4444", "border": "#334155"
        } if self.theme_dark else {
            "bg": "#eef2f7", "panel": "#ffffff", "panel2": "#f8fafc",
            "field": "#ffffff", "text": "#172033", "muted": "#64748b",
            "accent": "#2563eb", "accent_hover": "#1d4ed8", "good": "#16a34a",
            "warn": "#d97706", "bad": "#dc2626", "border": "#dbe3ee"
        }
        c=self.colors
        self.configure(bg=c["bg"])
        style=ttk.Style(self)
        try: style.theme_use("clam")
        except Exception: pass
        base_font=("Segoe UI",10)
        style.configure(".",font=base_font,background=c["bg"],foreground=c["text"])
        style.configure("TFrame",background=c["bg"])
        style.configure("Panel.TFrame",background=c["panel"],relief="flat")
        style.configure("Soft.TFrame",background=c["panel2"],relief="flat")
        style.configure("TLabel",background=c["bg"],foreground=c["text"])
        style.configure("Panel.TLabel",background=c["panel"],foreground=c["text"])
        style.configure("Muted.TLabel",background=c["panel"],foreground=c["muted"])
        style.configure("Hero.TLabel",background=c["panel"],foreground=c["text"],font=("Segoe UI Semibold",18))
        style.configure("CardTitle.TLabel",background=c["panel2"],foreground=c["muted"],font=("Segoe UI Semibold",9))
        style.configure("CardValue.TLabel",background=c["panel2"],foreground=c["text"],font=("Segoe UI Semibold",18))
        style.configure("TButton",padding=(12,8),background=c["panel2"],foreground=c["text"],borderwidth=0)
        style.map("TButton",background=[("active",c["border"]), ("pressed",c["border"])])
        style.configure("Accent.TButton",padding=(16,10),background=c["accent"],foreground="#ffffff",font=("Segoe UI Semibold",10),borderwidth=0)
        style.map("Accent.TButton",background=[("active",c["accent_hover"]), ("pressed",c["accent_hover"])])
        style.configure("Good.TButton",padding=(16,10),background=c["good"],foreground="#ffffff",font=("Segoe UI Semibold",10),borderwidth=0)
        style.map("Good.TButton",background=[("active",c["good"]), ("pressed",c["good"])])
        style.configure("TEntry",fieldbackground=c["field"],foreground=c["text"],insertcolor=c["text"],padding=7,bordercolor=c["border"],lightcolor=c["border"],darkcolor=c["border"])
        style.configure("TCombobox",fieldbackground=c["field"],foreground=c["text"],arrowcolor=c["text"],padding=6)
        style.configure("TSpinbox",fieldbackground=c["field"],foreground=c["text"],arrowcolor=c["text"],padding=6)
        style.configure("TCheckbutton",background=c["panel"],foreground=c["text"])
        style.map("TCheckbutton",background=[("active",c["panel"])])
        style.configure("TNotebook",background=c["bg"],borderwidth=0,tabmargins=(0,4,0,0))
        style.configure("TNotebook.Tab",padding=(15,9),background=c["panel2"],foreground=c["muted"],borderwidth=0)
        style.map("TNotebook.Tab",background=[("selected",c["panel"])],foreground=[("selected",c["accent"])])
        style.configure("Treeview",background=c["field"],fieldbackground=c["field"],foreground=c["text"],rowheight=30,borderwidth=0)
        style.map("Treeview",background=[("selected",c["accent"])],foreground=[("selected","#ffffff")])
        style.configure("Treeview.Heading",background=c["panel2"],foreground=c["text"],font=("Segoe UI Semibold",9),padding=(8,9),borderwidth=0)
        style.map("Treeview.Heading",background=[("active",c["border"])])
        style.configure("Horizontal.TProgressbar",troughcolor=c["panel2"],background=c["accent"],borderwidth=0,thickness=5)
        style.configure("Status.TLabel",background=c["panel"],foreground=c["muted"],padding=(10,7))

    def _ui(self):
        self._make_menu()
        self._configure_styles()
        c=self.colors

        shell=ttk.Frame(self,padding=(14,12,14,10)); shell.pack(fill="both",expand=True)

        header=ttk.Frame(shell,style="Panel.TFrame",padding=(18,14)); header.pack(fill="x",pady=(0,10))
        header.columnconfigure(0,weight=1)
        titlebox=ttk.Frame(header,style="Panel.TFrame"); titlebox.grid(row=0,column=0,sticky="w")
        self.title_label=ttk.Label(titlebox,text="Game Mod Localization Studio",style="Hero.TLabel"); self.title_label.pack(anchor="w")
        self.subtitle_label=ttk.Label(titlebox,text="Перевод модов Project Zomboid и RimWorld",style="Muted.TLabel"); self.subtitle_label.pack(anchor="w",pady=(2,0))
        ttk.Label(header,text="Игра:",style="Panel.TLabel").grid(row=0,column=1,padx=(10,4))
        game_combo=ttk.Combobox(header,textvariable=self.game,state="readonly",width=18,values=[GAME_PZ,GAME_RW]); game_combo.grid(row=0,column=2,padx=(0,8)); game_combo.bind("<<ComboboxSelected>>",self.on_game_changed)
        ttk.Button(header,text="☾  Тема",command=self.toggle_theme).grid(row=0,column=3,padx=(10,0))
        ttk.Button(header,text="Открыть результат",command=self.open_output).grid(row=0,column=4,padx=(8,0))

        project=ttk.Frame(shell,style="Panel.TFrame",padding=(16,12)); project.pack(fill="x",pady=(0,10))
        project.columnconfigure(1,weight=1)
        rows=(("Исходный мод или ZIP",self.source),("Таблица переводов",self.table),("Папка результата",self.output))
        for row,(label,var) in enumerate(rows):
            ttk.Label(project,text=label,style="Panel.TLabel",font=("Segoe UI Semibold",9)).grid(row=row,column=0,sticky="w",padx=(0,12),pady=5)
            ttk.Entry(project,textvariable=var).grid(row=row,column=1,sticky="ew",pady=5)
        ttk.Button(project,text="Папка",command=self.pick_source_folder).grid(row=0,column=2,padx=(8,4))
        ttk.Button(project,text="ZIP",command=self.pick_source_zip).grid(row=0,column=3)
        ttk.Button(project,text="Открыть",command=self.pick_table).grid(row=1,column=2,padx=(8,4))
        ttk.Button(project,text="Сохранить",command=self.save_table).grid(row=1,column=3)
        ttk.Button(project,text="Выбрать папку",command=self.pick_output).grid(row=2,column=2,columnspan=2,sticky="ew",padx=(8,0))

        toolbar=ttk.Frame(shell); toolbar.pack(fill="x",pady=(0,10))
        ttk.Button(toolbar,text="1  Сканировать",command=self.extract,style="Accent.TButton").pack(side="left")
        ttk.Button(toolbar,text="2  Автоперевод",command=self.open_ai_center).pack(side="left",padx=7)
        self.build_button=ttk.Button(toolbar,text="3  Создать русификатор",command=self.build,style="Good.TButton"); self.build_button.pack(side="left")
        ttk.Separator(toolbar,orient="vertical").pack(side="left",fill="y",padx=10)
        ttk.Button(toolbar,text="Проверка QA",command=self.validate_all).pack(side="left",padx=3)
        ttk.Button(toolbar,text="Умные инструменты",command=self.open_smart_tools).pack(side="left",padx=3)

        self.notebook=ttk.Notebook(shell); self.notebook.pack(fill="both",expand=True)
        editor=ttk.Frame(self.notebook,style="Panel.TFrame",padding=10); self.notebook.add(editor,text="  Редактор  ")
        filterbar=ttk.Frame(editor,style="Panel.TFrame"); filterbar.pack(fill="x",pady=(0,9))
        ttk.Label(filterbar,text="Поиск",style="Panel.TLabel").pack(side="left")
        ttk.Entry(filterbar,textvariable=self.search,width=42).pack(side="left",padx=(7,14))
        ttk.Label(filterbar,text="Показывать",style="Panel.TLabel").pack(side="left")
        combo=ttk.Combobox(filterbar,textvariable=self.filter,state="readonly",width=19,values=["Все","Не переведено","Переведено","Защищено","С ошибками"]); combo.pack(side="left",padx=7)
        self.search.trace_add("write",lambda *_:self.refresh()); combo.bind("<<ComboboxSelected>>",lambda e:self.refresh())

        pan=ttk.Panedwindow(editor,orient="horizontal"); pan.pack(fill="both",expand=True)
        left=ttk.Frame(pan,style="Panel.TFrame"); right=ttk.Frame(pan,style="Panel.TFrame",padding=(14,4)); pan.add(left,weight=3); pan.add(right,weight=2)
        cols=("status","source","translation","file","line","occ")
        self.tree=ttk.Treeview(left,columns=cols,show="headings",selectmode="browse")
        for col,text,width in (("status","Статус",85),("source","Оригинал",310),("translation","Перевод",310),("file","Файл",230),("line","Строка",62),("occ","Повторы",68)):
            self.tree.heading(col,text=text); self.tree.column(col,width=width,anchor="w",stretch=col not in ("line","occ","status"))
        sy=ttk.Scrollbar(left,orient="vertical",command=self.tree.yview); sx=ttk.Scrollbar(left,orient="horizontal",command=self.tree.xview); self.tree.configure(yscroll=sy.set,xscroll=sx.set)
        self.tree.grid(row=0,column=0,sticky="nsew"); sy.grid(row=0,column=1,sticky="ns"); sx.grid(row=1,column=0,sticky="ew"); left.rowconfigure(0,weight=1); left.columnconfigure(0,weight=1)
        self.tree.tag_configure("ready",foreground=c["good"]); self.tree.tag_configure("empty",foreground=c["muted"]); self.tree.tag_configure("error",foreground=c["bad"]); self.tree.tag_configure("protected",foreground=c["warn"])
        self.tree.bind("<<TreeviewSelect>>",self.select_row); self.tree.bind("<Button-3>",self.show_entry_menu)

        ttk.Label(right,text="ОРИГИНАЛ",style="Muted.TLabel",font=("Segoe UI Semibold",9)).pack(anchor="w")
        self.srcbox=tk.Text(right,height=6,wrap="word",state="disabled",relief="flat",padx=10,pady=9); self.srcbox.pack(fill="x",pady=(5,10))
        ttk.Label(right,text="ПЕРЕВОД",style="Muted.TLabel",font=("Segoe UI Semibold",9)).pack(anchor="w")
        self.trbox=tk.Text(right,height=8,wrap="word",relief="flat",padx=10,pady=9,undo=True); self.trbox.pack(fill="x",pady=(5,7)); self.trbox.bind("<KeyRelease>",self.edit_translation)
        self.protected=tk.BooleanVar(); ttk.Checkbutton(right,text="Защитить строку от автоматической замены",variable=self.protected,command=self.toggle_protected).pack(anchor="w",pady=(0,5))
        decision=ttk.Frame(right,style="Panel.TFrame"); decision.pack(fill="x",pady=(0,9))
        ttk.Button(decision,text="Принять несмотря на ошибку",command=self.accept_current_issue).pack(side="left")
        ttk.Button(decision,text="В защищённые",command=self.protect_current_issue).pack(side="left",padx=6)
        ttk.Button(decision,text="Очистить перевод",command=self.clear_current_translation).pack(side="left")
        ttk.Label(right,text="КОНТЕКСТ",style="Muted.TLabel",font=("Segoe UI Semibold",9)).pack(anchor="w")
        self.ctxbox=tk.Text(right,height=7,wrap="word",state="disabled",relief="flat",padx=10,pady=9); self.ctxbox.pack(fill="both",expand=True,pady=(5,6))
        self.issue=tk.StringVar(); ttk.Label(right,textvariable=self.issue,style="Panel.TLabel",foreground=c["bad"],wraplength=430).pack(anchor="w")
        sugg=ttk.Frame(right,style="Panel.TFrame"); sugg.pack(fill="x",pady=(8,0)); ttk.Button(sugg,text="Похожие переводы",command=self.show_suggestions).pack(side="left"); ttk.Button(sugg,text="Копировать оригинал",command=self.copy_source).pack(side="left",padx=6)

        glossary_tab=ttk.Frame(self.notebook,style="Panel.TFrame",padding=12); self.notebook.add(glossary_tab,text="  Словарь  ")
        gtop=ttk.Frame(glossary_tab,style="Panel.TFrame"); gtop.pack(fill="x",pady=(0,8))
        ttk.Button(gtop,text="Добавить термин",command=self.glossary_add,style="Accent.TButton").pack(side="left"); ttk.Button(gtop,text="Удалить",command=self.glossary_delete).pack(side="left",padx=5); ttk.Button(gtop,text="Сохранить",command=self.save_glossary).pack(side="left"); ttk.Button(gtop,text="Применить к пустым",command=self.apply_glossary).pack(side="left",padx=5)
        self.gtree=ttk.Treeview(glossary_tab,columns=("source","target"),show="headings"); self.gtree.heading("source",text="Термин"); self.gtree.heading("target",text="Перевод"); self.gtree.column("source",width=420); self.gtree.column("target",width=420); self.gtree.pack(fill="both",expand=True); self.gtree.bind("<Double-1>",self.glossary_edit); self.refresh_glossary()

        qa_tab=ttk.Frame(self.notebook,style="Panel.TFrame",padding=12); self.notebook.add(qa_tab,text="  Контроль качества  ")
        qbar=ttk.Frame(qa_tab,style="Panel.TFrame"); qbar.pack(fill="x",pady=(0,8)); ttk.Button(qbar,text="Запустить полную проверку",command=self.run_qa_report,style="Accent.TButton").pack(side="left"); ttk.Button(qbar,text="Сохранить отчёт",command=self.save_qa_report).pack(side="left",padx=6)
        self.qatree=ttk.Treeview(qa_tab,columns=("type","source","translation","file"),show="headings")
        for col,text,width in (("type","Проблема",190),("source","Оригинал",330),("translation","Перевод",330),("file","Файл",300)): self.qatree.heading(col,text=text); self.qatree.column(col,width=width)
        self.qatree.pack(fill="both",expand=True); self.qatree.bind("<Double-1>",self.qa_jump)

        stats=ttk.Frame(self.notebook,style="Panel.TFrame",padding=16); self.notebook.add(stats,text="  Панель проекта  ")
        cards=ttk.Frame(stats,style="Panel.TFrame"); cards.pack(fill="x",pady=(0,12))
        self.metric_vars={k:tk.StringVar(value="0") for k in ("total","translated","empty","protected","errors")}
        for idx,(key,title) in enumerate((("total","ВСЕГО СТРОК"),("translated","ПЕРЕВЕДЕНО"),("empty","ОСТАЛОСЬ"),("protected","ЗАЩИЩЕНО"),("errors","ОШИБКИ"))):
            card=ttk.Frame(cards,style="Soft.TFrame",padding=(14,11)); card.grid(row=0,column=idx,sticky="ew",padx=(0 if idx==0 else 5,0)); cards.columnconfigure(idx,weight=1)
            ttk.Label(card,text=title,style="CardTitle.TLabel").pack(anchor="w"); ttk.Label(card,textvariable=self.metric_vars[key],style="CardValue.TLabel").pack(anchor="w",pady=(3,0))
        self.stats=tk.Text(stats,wrap="word",state="disabled",relief="flat",padx=14,pady=12); self.stats.pack(fill="both",expand=True)

        statusbar=ttk.Frame(shell,style="Panel.TFrame"); statusbar.pack(fill="x",pady=(10,0))
        self.progress=ttk.Progressbar(statusbar,mode="indeterminate",style="Horizontal.TProgressbar"); self.progress.pack(fill="x")
        ttk.Label(statusbar,textvariable=self.status,style="Status.TLabel",anchor="w").pack(fill="x")
        self._apply_text_colors()

    def _apply_text_colors(self):
        c=self.colors
        for widget in (self.srcbox,self.trbox,self.ctxbox,self.stats):
            try:
                widget.configure(bg=c["field"],fg=c["text"],insertbackground=c["text"],selectbackground=c["accent"],selectforeground="#ffffff")
            except Exception: pass
    def _make_menu(self):
        m=tk.Menu(self); self.config(menu=m)
        fm=tk.Menu(m,tearoff=0); m.add_cascade(label="Проект",menu=fm)
        fm.add_command(label="Новый проект",command=self.new_project)
        fm.add_command(label="Открыть проект…",command=self.open_project)
        fm.add_command(label="Сохранить проект",command=self.save_project)
        fm.add_separator(); fm.add_command(label="Выход",command=self.on_close)
        tm=tk.Menu(m,tearoff=0); m.add_cascade(label="Инструменты",menu=tm)
        tm.add_command(label="Импорт памяти…",command=self.import_memory)
        tm.add_command(label="Экспорт памяти",command=self.export_memory)
        tm.add_command(label="Менеджер памяти переводов…",command=self.open_translation_memory_manager)
        tm.add_command(label="Умные инструменты…",command=self.open_smart_tools)
        tm.add_command(label="Предпросмотр сборки…",command=self.preview_build)
        tm.add_command(label="Проверить, нужен ли перевод…",command=self.check_translation_need)
        tm.add_command(label="Менеджер проектов и пакетов…",command=self.open_project_manager)
        tm.add_command(label="Восстановить резервную копию…",command=self.restore_snapshot)
        tm.add_command(label="Экспорт XLSX",command=self.export_xlsx)
        tm.add_separator(); tm.add_command(label="Центр автоматического перевода…",command=self.open_ai_center)
        tm.add_command(label="Сменить светлую/тёмную тему",command=self.toggle_theme)
        hm=tk.Menu(m,tearoff=0); m.add_cascade(label="Справка",menu=hm); hm.add_command(label="О программе",command=lambda:messagebox.showinfo(APP_TITLE,"Game Mod Localization Studio 8.3\nПеревод модов Project Zomboid и RimWorld."))

    def on_game_changed(self,event=None):
        self.settings["last_game"]=self.game.get();self.save_settings()
        game=self.game.get()
        self.subtitle_label.configure(text=("Перевод и сборка русификаторов Project Zomboid" if game==GAME_PZ else "Перевод модов RimWorld: Keyed, DefInjected и Strings"))
        self.build_button.configure(text=("3  Создать русификатор PZ" if game==GAME_PZ else "3  Создать перевод RimWorld"))
        self.status.set(f"Выбрана игра: {game}")

    def choose_game_dialog(self):
        win=tk.Toplevel(self);win.title("Новый проект — выбор игры");win.transient(self);win.grab_set();win.resizable(False,False)
        ttk.Label(win,text="Для какой игры создать перевод?",font=("Segoe UI Semibold",14)).pack(padx=30,pady=(24,14))
        choice=tk.StringVar(value=self.game.get())
        ttk.Radiobutton(win,text="Project Zomboid (Build 41 / Build 42)",variable=choice,value=GAME_PZ).pack(anchor="w",padx=30,pady=7)
        ttk.Radiobutton(win,text="RimWorld (Keyed / DefInjected / Strings)",variable=choice,value=GAME_RW).pack(anchor="w",padx=30,pady=7)
        def ok():self.game.set(choice.get());self.on_game_changed();win.destroy()
        ttk.Button(win,text="Создать проект",style="Accent.TButton",command=ok).pack(pady=(18,24))
        self.wait_window(win)

    def new_project(self):
        if self.dirty and not messagebox.askyesno(APP_TITLE,"Отбросить несохранённые изменения?"): return
        self.choose_game_dialog(); self.entries=[]; self.source.set(""); self.output.set(str(Path.cwd()/"output")); self.table.set(str(Path.cwd()/"translations.csv")); self.project_path=None; self.dirty=False; self.refresh()

    def save_project(self):
        if not self.project_path:
            p=filedialog.asksaveasfilename(defaultextension=PROJECT_EXT,filetypes=[("PZ Localization Project","*.pzloc")])
            if not p:return
            self.project_path=Path(p)
        data={"version":5,"game":self.game.get(),"source":self.source.get(),"table":self.table.get(),"output":self.output.get(),"saved":datetime.now().isoformat(timespec="seconds")}
        self.project_path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        self.save_table(); self.register_current_project(); self.status.set(f"Проект сохранён: {self.project_path.name}")

    def open_project(self):
        p=filedialog.askopenfilename(filetypes=[("PZ Localization Project","*.pzloc")])
        if not p:return
        try:
            data=json.loads(Path(p).read_text(encoding="utf-8"))
            if not isinstance(data,dict): raise ValueError("Файл проекта имеет неверный формат")
            self.project_path=Path(p); self.game.set(data.get("game",GAME_PZ)); self.on_game_changed(); self.source.set(data.get("source","")); self.table.set(data.get("table","")); self.output.set(data.get("output",str(Path.cwd()/"output")))
            tp=Path(self.table.get())
            if tp.exists() and tp.is_file(): self.load_table(tp)
            else: self.entries=[]; self.dirty=False; self.refresh(); self.status.set("Проект открыт, но таблица переводов не найдена")
        except Exception as e:
            messagebox.showerror(APP_TITLE,f"Не удалось открыть проект:\n{e}")

    def toggle_theme(self):
        self.theme_dark=not self.theme_dark
        self.settings["theme_dark"]=self.theme_dark
        self.save_settings()
        self._configure_styles()
        self._apply_text_colors()
        self.refresh()

    def load_settings(self):
        p=Path.cwd()/SETTINGS_FILE
        defaults={"memory_enabled":True,"normalized_memory":True,"length_ratio":2.4,"profile":"Общий","auto_snapshot":True,"context_export":True,"theme_dark":True,"last_game":GAME_PZ}
        try:
            if p.exists():defaults.update(json.loads(p.read_text(encoding='utf-8')))
        except Exception:pass
        return defaults

    def save_settings(self):
        (Path.cwd()/SETTINGS_FILE).write_text(json.dumps(self.settings,ensure_ascii=False,indent=2),encoding='utf-8')

    def profile_glossary(self):
        result=dict(PROFILE_TERMS.get(self.settings.get('profile','Общий'),{})); result.update(self.glossary); return result

    def create_snapshot(self,label='auto'):
        if not self.settings.get('auto_snapshot',True) or not self.entries:return None
        folder=Path.cwd()/"backups"/"snapshots";folder.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); path=folder/f'{stamp}_{label}.json'
        write_json(self.entries,path)
        files=sorted(folder.glob('*.json'),key=lambda x:x.stat().st_mtime,reverse=True)
        for old in files[20:]:
            try:old.unlink()
            except Exception:pass
        return path

    def restore_snapshot(self):
        folder=Path.cwd()/"backups"/"snapshots";folder.mkdir(parents=True,exist_ok=True)
        p=filedialog.askopenfilename(initialdir=str(folder),filetypes=[('Snapshot JSON','*.json')])
        if not p:return
        try:self.entries=load_rows(Path(p));self.dirty=True;self.refresh();messagebox.showinfo(APP_TITLE,f'Восстановлено строк: {len(self.entries)}')
        except Exception as e:messagebox.showerror(APP_TITLE,str(e))

    def load_glossary(self):
        p=Path.cwd()/GLOSSARY_FILE
        try:return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"Trader":"Торговец","Settlement":"Поселение","Objective":"Задание","Buy":"Купить","Sell":"Продать"}
        except:return {}

    def save_glossary(self):
        (Path.cwd()/GLOSSARY_FILE).write_text(json.dumps(self.glossary,ensure_ascii=False,indent=2),encoding="utf-8"); self.status.set("Словарь сохранён")

    def refresh_glossary(self):
        if not hasattr(self,"gtree"):return
        self.gtree.delete(*self.gtree.get_children())
        for i,(s,t) in enumerate(sorted(self.glossary.items(),key=lambda x:x[0].lower())): self.gtree.insert("","end",iid=str(i),values=(s,t))

    def glossary_add(self):
        win=tk.Toplevel(self); win.title("Новый термин"); win.transient(self); win.grab_set(); sv=tk.StringVar(); tv=tk.StringVar()
        ttk.Label(win,text="Термин").grid(row=0,column=0,padx=8,pady=8); ttk.Entry(win,textvariable=sv,width=45).grid(row=0,column=1,padx=8)
        ttk.Label(win,text="Перевод").grid(row=1,column=0,padx=8,pady=8); ttk.Entry(win,textvariable=tv,width=45).grid(row=1,column=1,padx=8)
        def ok():
            if sv.get().strip():self.glossary[sv.get().strip()]=tv.get().strip();self.refresh_glossary();self.save_glossary();win.destroy()
        ttk.Button(win,text="Сохранить",command=ok).grid(row=2,column=0,columnspan=2,pady=10)

    def glossary_delete(self):
        sel=self.gtree.selection();
        if not sel:return
        src=self.gtree.item(sel[0],"values")[0]; self.glossary.pop(src,None); self.refresh_glossary(); self.save_glossary()

    def glossary_edit(self,event=None):
        sel=self.gtree.selection()
        if not sel:return
        old_src,old_tgt=self.gtree.item(sel[0],"values")
        win=tk.Toplevel(self); win.title("Изменить термин"); win.transient(self); win.grab_set()
        sv=tk.StringVar(value=old_src); tv=tk.StringVar(value=old_tgt)
        ttk.Label(win,text="Термин").grid(row=0,column=0,padx=8,pady=8); ttk.Entry(win,textvariable=sv,width=45).grid(row=0,column=1,padx=8)
        ttk.Label(win,text="Перевод").grid(row=1,column=0,padx=8,pady=8); ttk.Entry(win,textvariable=tv,width=45).grid(row=1,column=1,padx=8)
        def ok():
            new_src=sv.get().strip(); new_tgt=tv.get().strip()
            if not new_src:return
            self.glossary.pop(old_src,None); self.glossary[new_src]=new_tgt
            self.refresh_glossary(); self.save_glossary(); win.destroy()
        ttk.Button(win,text="Сохранить",command=ok).grid(row=2,column=0,columnspan=2,pady=10)

    def apply_glossary(self):
        count=0
        for e in self.entries:
            if e.translation.strip() or e.protected=="yes":continue
            if e.source_text in self.glossary:
                e.translation=self.glossary[e.source_text];e.status="translated";count+=1
            else:
                target=e.source_text
                changed=False
                for s,t in sorted(self.glossary.items(),key=lambda x:len(x[0]),reverse=True):
                    new=re.sub(r"\b"+re.escape(s)+r"\b",t,target,flags=re.I)
                    changed|=new!=target;target=new
                if changed and target!=e.source_text:e.translation=target;e.status="translated";count+=1
        self.dirty|=bool(count);self.refresh();messagebox.showinfo(APP_TITLE,f"Словарь применён к {count} строкам")

    def show_suggestions(self):
        if not self.current:return
        candidates=[e for e in self.entries if e.translation.strip() and e is not self.current]
        scored=sorted(((difflib.SequenceMatcher(None,self.current.source_text.lower(),e.source_text.lower()).ratio(),e.source_text,e.translation) for e in candidates),reverse=True,key=lambda x:x[0])[:8]
        for score,src,tr,status,uses in self.tmdb.suggestions(self.current.source_text,8):
            scored.append((score,src,tr))
        scored=sorted(scored,reverse=True,key=lambda x:x[0])[:8]
        win=tk.Toplevel(self);win.title("Похожие переводы");win.geometry("900x420");tree=ttk.Treeview(win,columns=("score","source","translation"),show="headings");
        for c,t,w in (("score","Сходство",90),("source","Оригинал",360),("translation","Перевод",360)):tree.heading(c,text=t);tree.column(c,width=w)
        tree.pack(fill="both",expand=True,padx=8,pady=8)
        for i,(score,src,tr) in enumerate(scored):tree.insert("","end",iid=str(i),values=(f"{score*100:.0f}%",src,tr))
        def use():
            sel=tree.selection();
            if sel:self.trbox.delete("1.0","end");self.trbox.insert("1.0",tree.item(sel[0],"values")[2]);self.edit_translation();win.destroy()
        ttk.Button(win,text="Использовать выбранный перевод",command=use).pack(pady=(0,8))

    def copy_source(self):
        if self.current:self.trbox.delete("1.0","end");self.trbox.insert("1.0",self.current.source_text);self.edit_translation()

    def collect_qa(self):
        out=[]; seen={}; representatives={}
        try: length_ratio=float(self.settings.get("length_ratio",2.4))
        except (TypeError,ValueError): length_ratio=2.4
        for e in self.entries:
            if e.translation:
                issue=entry_issue(e)
                if issue:out.append((issue,e))
                if e.translation.strip()==e.source_text.strip():out.append(("Перевод совпадает с оригиналом",e))
                ratio=len(e.translation.strip())/max(1,len(e.source_text.strip()))
                if len(e.translation.strip())>=28 and ratio>length_ratio:
                    out.append((f"Перевод может не поместиться ({ratio:.1f}× длиннее)",e))
                key=normalize_memory_key(e.source_text)
                seen.setdefault(key,set()).add(e.translation.strip()); representatives.setdefault(key,e)
        for key,vals in seen.items():
            if len(vals)>1: out.append(("Несогласованные варианты перевода",representatives[key]))
        return out

    def run_qa_report(self):
        issues=self.collect_qa(); self.qatree.delete(*self.qatree.get_children())
        for i,(kind,e) in enumerate(issues):self.qatree.insert("","end",iid=str(i),values=(kind,e.source_text,e.translation,e.file))
        self.status.set(f"QA завершён: {len(issues)} проблем")

    def save_qa_report(self):
        issues=self.collect_qa();p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")]);
        if not p:return
        with open(p,"w",encoding="utf-8-sig",newline="") as f:
            w=csv.writer(f,delimiter=";");w.writerow(["problem","source","translation","file","line"])
            for k,e in issues:w.writerow([k,e.source_text,e.translation,e.file,e.line])

    def qa_jump(self,event=None):
        sel=self.qatree.selection();
        if not sel:return
        src=self.qatree.item(sel[0],"values")[1];self.search.set(src)

    def export_xlsx(self):
        p=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel","*.xlsx")]);
        if not p:return
        ok,err=write_xlsx(self.entries,Path(p)); messagebox.showinfo(APP_TITLE,"XLSX сохранён" if ok else err)

    def pick_source_folder(self):
        p=filedialog.askdirectory();
        if p:self.source.set(p)
    def pick_source_zip(self):
        p=filedialog.askopenfilename(filetypes=[("ZIP","*.zip")]);
        if p:self.source.set(p)
    def pick_table(self):
        p=filedialog.askopenfilename(filetypes=[("Таблицы","*.csv *.xlsx *.json")]);
        if p:self.table.set(p);self.load_table(Path(p))
    def pick_output(self):
        p=filedialog.askdirectory();
        if p:self.output.set(p)
    def set_text(self,widget,text):
        widget.config(state="normal");widget.delete("1.0","end");widget.insert("1.0",text);widget.config(state="disabled")
    def load_table(self,path):
        try:self.entries=load_rows(path);self.dirty=False;self.refresh();self.status.set(f"Загружено строк: {len(self.entries)}")
        except Exception as e:messagebox.showerror(APP_TITLE,str(e))
    def save_table(self):
        path=Path(self.table.get()); path.parent.mkdir(parents=True,exist_ok=True); backup(path,Path.cwd()/"backups")
        try:
            ext=path.suffix.lower();
            if ext==".json":write_json(self.entries,path)
            elif ext==".xlsx":
                ok,err=write_xlsx(self.entries,path)
                if not ok:raise RuntimeError(err)
            else:write_csv(self.entries,path)
            write_json(self.entries,path.with_suffix(".json")); self.create_snapshot("save"); self.tmdb.add_many(self.entries,Path(self.source.get()).name if self.source.get() else ""); self.dirty=False;self.status.set("Таблица сохранена")
        except Exception as e:messagebox.showerror(APP_TITLE,str(e))
    def refresh(self):
        q=self.search.get().strip().lower(); f=self.filter.get(); self.visible=[]
        for e in self.entries:
            issue=entry_issue(e)
            ok=(not q or q in e.source_text.lower() or q in e.translation.lower() or q in e.file.lower() or q in e.context.lower())
            if f=="Не переведено":ok &= not bool(e.translation.strip()) and e.protected!="yes"
            elif f=="Переведено":ok &= bool(e.translation.strip())
            elif f=="Защищено":ok &= e.protected=="yes"
            elif f=="С ошибками":ok &= bool(issue)
            if ok:self.visible.append(e)
        self.tree.delete(*self.tree.get_children())
        for i,e in enumerate(self.visible):
            issue=entry_issue(e)
            status="Принято" if e.status=="accepted" else ("Ошибка" if issue else ("Защита" if e.protected=="yes" else ("Готово" if e.translation.strip() else "Пусто")))
            tag="error" if issue else ("protected" if e.protected=="yes" else ("ready" if e.translation.strip() else "empty"))
            self.tree.insert("", "end", iid=str(i), values=(status,e.source_text,e.translation,e.file,e.line,e.occurrences),tags=(tag,))
        total=len(self.entries); translated=sum(e.protected!="yes" and bool(e.translation.strip()) and e.translation.strip()!=e.source_text.strip() for e in self.entries); protected=sum(e.protected=="yes" for e in self.entries); errors=sum(bool(entry_issue(e)) for e in self.entries if e.translation)
        empty=max(0,total-translated-protected)
        if hasattr(self,"metric_vars"):
            self.metric_vars["total"].set(str(total)); self.metric_vars["translated"].set(str(translated)); self.metric_vars["empty"].set(str(empty)); self.metric_vars["protected"].set(str(protected)); self.metric_vars["errors"].set(str(errors))
        self.set_text(self.stats,f"Всего строк: {total}\nПереведено: {translated}\nНе переведено: {empty}\nЗащищено: {protected}\nОшибок проверки: {errors}\n\nПрогресс: {((translated/max(1,total-protected))*100):.1f}%\n\nВОЗМОЖНОСТИ PRO\n• Проекты .pzloc\n• Память переводов\n• Словарь терминов\n• Поиск похожих переводов\n• QA-проверка заполнителей и переносов\n• Перенос переводов после обновления мода\n• Gemini, OpenRouter, Groq, OpenAI, DeepSeek и локальные модели\n• Ручное принятие QA-ошибок и перенос строк в защищённые\n• Автосохранение пакетного перевода\n• Отдельная безопасная сборка ZIP\n\nОригинальные файлы никогда не изменяются.")
    def select_row(self,event=None):
        sel=self.tree.selection();
        if not sel:return
        self.current=self.visible[int(sel[0])]; e=self.current
        self.set_text(self.srcbox,e.source_text); self.trbox.delete("1.0","end");self.trbox.insert("1.0",e.translation);self.set_text(self.ctxbox,f"{e.file}:{e.line}\n\n{e.context}");self.protected.set(e.protected=="yes");self.issue.set(entry_issue(e))
    def edit_translation(self,event=None):
        if not self.current:return
        self.current.translation=self.trbox.get("1.0","end-1c")
        self.current.status="translated" if self.current.translation.strip() else "not_translated"
        self.dirty=True
        self.issue.set(entry_issue(self.current))
        self.update_current_row()
    def toggle_protected(self):
        if not self.current:return
        self.current.protected="yes" if self.protected.get() else "no";self.current.status="protected" if self.protected.get() else ("translated" if self.current.translation else "not_translated");self.dirty=True;self.update_current_row()
    def update_current_row(self):
        sel=self.tree.selection();
        if sel:
            e=self.current;issue=entry_issue(e);status="Принято" if e.status=="accepted" else ("Ошибка" if issue else ("Защита" if e.protected=="yes" else ("Готово" if e.translation.strip() else "Пусто")));self.tree.item(sel[0],values=(status,e.source_text,e.translation,e.file,e.line,e.occurrences))
    def accept_current_issue(self):
        if not self.current or not self.current.translation.strip():
            messagebox.showwarning(APP_TITLE,"Сначала введите перевод")
            return
        self.current.status="accepted"
        self.current.protected="no"
        self.protected.set(False)
        self.issue.set("")
        self.dirty=True
        self.update_current_row(); self.refresh()

    def protect_current_issue(self):
        if not self.current:return
        self.current.protected="yes"
        self.current.status="protected"
        self.protected.set(True)
        self.issue.set("")
        self.dirty=True
        self.update_current_row(); self.refresh()

    def clear_current_translation(self):
        if not self.current:return
        self.current.translation=""
        self.current.status="not_translated"
        self.current.protected="no"
        self.protected.set(False)
        self.trbox.delete("1.0","end")
        self.issue.set("")
        self.dirty=True
        self.update_current_row(); self.refresh()

    def show_entry_menu(self,event):
        row=self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row); self.tree.focus(row); self.select_row()
        menu=tk.Menu(self,tearoff=False)
        menu.add_command(label="Принять перевод несмотря на ошибку",command=self.accept_current_issue)
        menu.add_command(label="Переместить в защищённые",command=self.protect_current_issue)
        menu.add_command(label="Очистить перевод",command=self.clear_current_translation)
        menu.add_separator()
        menu.add_command(label="Принять все показанные ошибки",command=self.accept_visible_issues)
        menu.add_command(label="Защитить все показанные ошибки",command=self.protect_visible_issues)
        try: menu.tk_popup(event.x_root,event.y_root)
        finally: menu.grab_release()

    def accept_visible_issues(self):
        changed=0
        for e in self.visible:
            if e.translation and entry_issue(e):
                e.status="accepted"; e.protected="no"; changed+=1
        self.dirty|=bool(changed); self.refresh()
        messagebox.showinfo(APP_TITLE,f"Принято вручную: {changed}")

    def protect_visible_issues(self):
        changed=0
        for e in self.visible:
            if e.translation and entry_issue(e):
                e.status="protected"; e.protected="yes"; changed+=1
        self.dirty|=bool(changed); self.refresh()
        messagebox.showinfo(APP_TITLE,f"Перемещено в защищённые: {changed}")

    def run(self,label,fn):
        self.status.set(label);self.progress.start(10);self.update_idletasks()
        try:r=fn();self.status.set(r);messagebox.showinfo(APP_TITLE,r)
        except Exception as e:messagebox.showerror(APP_TITLE,f"{e}\n\n{traceback.format_exc(limit=4)}")
        finally:self.progress.stop()
    def extract(self):
        src=Path(self.source.get().strip());out=Path(self.output.get().strip())
        if not src.exists():messagebox.showwarning(APP_TITLE,"Выберите папку или ZIP");return
        def work():
            out.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryDirectory(prefix="pzloc2_") as td:
                prepared_root=prepare_source(src,Path(td))
                detected=detect_game_structure(prepared_root)
                if detected and detected!=self.game.get():
                    raise ValueError(f"Выбрана игра {self.game.get()}, но структура похожа на {detected}. Создайте проект для правильной игры или измените выбор игры.")
                new=extract_entries(prepared_root) if self.game.get()==GAME_PZ else extract_rimworld_entries(prepared_root)
                source_analysis=count_scripts_and_languages(prepared_root) if self.game.get()==GAME_PZ else {"status":("Перевод требуется" if new else "Локализуемый текст не найден"),"confidence":"high","reason":"Анализ структуры RimWorld","english_strings":len(new)}
            old={e.source_text:e for e in self.entries}; memory=self.load_memory_file(); old_sources=set(old)
            carried=from_memory=from_normalized=new_count=0
            for e in new:
                if e.source_text in old:
                    e.translation=old[e.source_text].translation;e.protected=old[e.source_text].protected
                    if e.translation: carried+=1
                elif self.settings.get("memory_enabled",True):
                    mt,kind=self.tmdb.lookup(e.source_text,self.settings.get("normalized_memory",True))
                    if mt:
                        e.translation=mt
                        if kind=="normalized":from_normalized+=1
                        else:from_memory+=1
                    elif e.source_text in memory:e.translation=memory[e.source_text];from_memory+=1
                    else:new_count+=1
                else:new_count+=1
                e.status="protected" if e.protected=="yes" else ("translated" if e.translation else "not_translated")
            removed=len(old_sources-{e.source_text for e in new})
            self.entries=new;path=out/"translations.csv";self.table.set(str(path));write_csv(new,path);write_json(new,out/"translations.json");write_xlsx(new,out/"translations.xlsx");self.refresh();self.dirty=False
            update_report={"date":datetime.now().isoformat(timespec="seconds"),"total":len(new),"new_strings":new_count,"removed_strings":removed,"translations_carried":carried,"from_memory":from_memory,"from_normalized_memory":from_normalized}
            (out/"update_report.json").write_text(json.dumps(update_report,ensure_ascii=False,indent=2),encoding="utf-8")
            if source_analysis:
                update_report["translation_need_analysis"]=source_analysis
                (out/"update_report.json").write_text(json.dumps(update_report,ensure_ascii=False,indent=2),encoding="utf-8")
            status_text=source_analysis["status"] if source_analysis else ("Перевод требуется" if len(new)>0 else "Локализуемый текст не найден")
            (out/"update_report.txt").write_text(f"ОТЧЁТ ОБ ОБНОВЛЕНИИ\nСтатус: {status_text}\nВсего строк: {len(new)}\nНовых строк: {new_count}\nУдалено из новой версии: {removed}\nПеренесено старых переводов: {carried}\nПодставлено из памяти: {from_memory}\nПо нормализованному совпадению: {from_normalized}\n",encoding="utf-8")
            return f"{status_text}. Найдено {len(new)} строк. Новых: {new_count}; перенесено: {carried}; из памяти: {from_memory+from_normalized}; удалено: {removed}."
        self.run("Сканирование…",work)
    def validate_all(self):
        errors=[e for e in self.entries if e.translation and entry_issue(e)]
        self.filter.set("С ошибками");self.refresh();messagebox.showinfo(APP_TITLE,f"Проверено. Ошибок: {len(errors)}")
    def memory_path(self):return Path.cwd()/"translation_memory.json"
    def load_memory_file(self):
        p=self.memory_path()
        try:return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        except:return {}
    def export_memory(self):
        self.tmdb.add_many(self.entries,Path(self.source.get()).name if self.source.get() else "")
        p=filedialog.asksaveasfilename(defaultextension='.json',initialfile='translation_memory_export.json',filetypes=[('JSON','*.json')])
        if not p:return
        self.tmdb.export_json(Path(p)); count,verified,size=self.tmdb.stats();messagebox.showinfo(APP_TITLE,f"Экспортировано: {count} записей\nРазмер базы: {size/1024/1024:.2f} МБ")
    def open_translation_memory_manager(self):
        win=tk.Toplevel(self);win.title('Память переводов 8.3');win.geometry('1180x720');win.transient(self)
        toolbar=ttk.Frame(win,padding=10);toolbar.pack(fill='x')
        query=tk.StringVar();limit=tk.IntVar(value=1000);stats_var=tk.StringVar()
        ttk.Label(toolbar,text='Поиск:').pack(side='left')
        search=ttk.Entry(toolbar,textvariable=query,width=42);search.pack(side='left',padx=6)
        ttk.Label(toolbar,text='Показать:').pack(side='left',padx=(8,0));ttk.Spinbox(toolbar,from_=100,to=5000,increment=100,textvariable=limit,width=7).pack(side='left',padx=5)
        ttk.Label(toolbar,textvariable=stats_var).pack(side='right')
        cols=('source','translation','status','uses','mod','updated')
        tree=ttk.Treeview(win,columns=cols,show='headings',selectmode='extended')
        specs=(('source','Оригинал',330),('translation','Перевод',330),('status','Статус',90),('uses','Использований',95),('mod','Источник',160),('updated','Обновлено',145))
        for c,t,w in specs:tree.heading(c,text=t);tree.column(c,width=w,anchor='w')
        y=ttk.Scrollbar(win,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=y.set)
        tree.pack(side='left',fill='both',expand=True,padx=(10,0),pady=(0,10));y.pack(side='left',fill='y',pady=(0,10))
        side=ttk.Frame(win,padding=12);side.pack(side='right',fill='y',padx=10,pady=(0,10))
        src=tk.Text(side,width=38,height=9,wrap='word');tr=tk.Text(side,width=38,height=9,wrap='word')
        status=tk.StringVar(value='verified')
        ttk.Label(side,text='Оригинал',font=('Segoe UI Semibold',10)).pack(anchor='w');src.pack(fill='x',pady=(3,10))
        ttk.Label(side,text='Перевод',font=('Segoe UI Semibold',10)).pack(anchor='w');tr.pack(fill='x',pady=(3,10))
        ttk.Label(side,text='Статус').pack(anchor='w');ttk.Combobox(side,textvariable=status,state='readonly',values=('verified','draft'),width=18).pack(anchor='w',pady=(3,12))
        selected_source={'value':''}
        def refresh(*_):
            for item in tree.get_children():tree.delete(item)
            try:rows=self.tmdb.search_rows(query.get(),limit.get())
            except Exception as ex:messagebox.showerror(APP_TITLE,str(ex),parent=win);return
            for row in rows:tree.insert('', 'end', values=row)
            count,verified,size=self.tmdb.stats();stats_var.set(f'Всего: {count}   Проверенных: {verified}   Размер: {size/1024/1024:.2f} МБ   Найдено: {len(rows)}')
        def load_selected(_=None):
            sel=tree.selection()
            if not sel:return
            vals=tree.item(sel[0],'values');selected_source['value']=vals[0]
            src.delete('1.0','end');src.insert('1.0',vals[0]);tr.delete('1.0','end');tr.insert('1.0',vals[1]);status.set(vals[2] or 'verified')
        def save_row():
            try:
                old=selected_source['value'];new_src=src.get('1.0','end-1c').strip();new_tr=tr.get('1.0','end-1c').strip()
                self.tmdb.update_row(old,new_src,new_tr,status.get());selected_source['value']=new_src;refresh();self.status.set('Запись памяти сохранена')
            except Exception as ex:messagebox.showerror(APP_TITLE,str(ex),parent=win)
        def new_row():
            selected_source['value']='';src.delete('1.0','end');tr.delete('1.0','end');status.set('verified');src.focus_set()
        def delete_selected():
            sel=tree.selection()
            if not sel:return
            sources=[tree.item(x,'values')[0] for x in sel]
            if messagebox.askyesno(APP_TITLE,f'Удалить записей: {len(sources)}?',parent=win):self.tmdb.delete_rows(sources);new_row();refresh()
        def apply_project():
            changed=0
            for e in self.entries:
                if e.protected=='yes' or e.translation.strip():continue
                t,_=self.tmdb.lookup(e.source_text,self.settings.get('normalized_memory',True))
                if t and not validate_translation(e.source_text,t):e.translation=t;e.status='translated';changed+=1
            if changed:self.dirty=True;self.refresh()
            messagebox.showinfo(APP_TITLE,f'В текущий проект подставлено: {changed}',parent=win)
        def optimize():
            try:self.tmdb.optimize();refresh();messagebox.showinfo(APP_TITLE,'База оптимизирована.',parent=win)
            except Exception as ex:messagebox.showerror(APP_TITLE,str(ex),parent=win)
        for text,cmd in (('Новая запись',new_row),('Сохранить',save_row),('Удалить выбранные',delete_selected),('Применить к проекту',apply_project),('Оптимизировать базу',optimize),('Импорт…',self.import_memory),('Экспорт…',self.export_memory)):
            ttk.Button(side,text=text,command=cmd).pack(fill='x',pady=3)
        ttk.Label(side,text='Двойной щелчок по строке открывает её для редактирования. Можно выделить несколько строк и удалить их разом.',wraplength=285,justify='left').pack(anchor='w',pady=(14,0))
        tree.bind('<<TreeviewSelect>>',load_selected);tree.bind('<Double-1>',load_selected);search.bind('<Return>',refresh)
        ttk.Button(toolbar,text='Найти',command=refresh).pack(side='left',padx=4);ttk.Button(toolbar,text='Сбросить',command=lambda:(query.set(''),refresh())).pack(side='left')
        refresh();search.focus_set()

    def import_memory(self):
        p=filedialog.askopenfilename(filetypes=[("JSON","*.json"),("CSV","*.csv")]);
        if not p:return
        try:
            if Path(p).suffix.lower()=='.csv':
                rows=load_rows(Path(p));data=[asdict(e) for e in rows]
            else:data=json.loads(Path(p).read_text(encoding='utf-8-sig'))
            imported=self.tmdb.import_data(data)
            count=0
            for e in self.entries:
                if not e.translation:
                    t,_=self.tmdb.lookup(e.source_text,self.settings.get('normalized_memory',True))
                    if t:e.translation=t;e.status='translated';count+=1
            self.dirty|=bool(count);self.refresh();messagebox.showinfo(APP_TITLE,f"В базу добавлено: {imported}\nПодставлено в проект: {count}")
        except Exception as ex:messagebox.showerror(APP_TITLE,str(ex))

    def ai_candidates(self, only_visible=False):
        base=self.visible if only_visible else self.entries
        return [e for e in base if e.protected!="yes" and not e.translation.strip()]

    def apply_translation_memory_before_ai(self, only_visible=False):
        """Подставляет корректные совпадения из Translation Memory до отправки строк в ИИ.

        Возвращает (оставшиеся_кандидаты, точные, нормализованные, отклонённые_QA).
        Отклонённые записи не применяются и остаются кандидатами для ИИ.
        """
        candidates=self.ai_candidates(only_visible)
        if not candidates or not self.settings.get("memory_enabled",True):
            return candidates,0,0,0
        allow_normalized=self.settings.get("normalized_memory",True)
        exact=normalized=rejected=0
        # Локальный кэш исключает повторные обращения к SQLite для дублей в проекте.
        lookup_cache={}
        for e in candidates:
            key=e.source_text
            if key not in lookup_cache:
                try: lookup_cache[key]=self.tmdb.lookup(key,allow_normalized)
                except Exception: lookup_cache[key]=(None,None)
            translation,match_kind=lookup_cache[key]
            if not translation:
                continue
            if validate_translation(e.source_text,translation):
                rejected+=1
                continue
            e.translation=translation
            e.status="translated"
            if match_kind=="normalized": normalized+=1
            else: exact+=1
        applied=exact+normalized
        if applied:
            self.dirty=True
            self.refresh()
            self.save_table()
        return self.ai_candidates(only_visible),exact,normalized,rejected

    def open_ai_center(self):
        win=tk.Toplevel(self); win.title("Центр перевода 8.4 — Translation Memory перед ИИ"); win.geometry("900x735"); win.transient(self)
        nb=ttk.Notebook(win); nb.pack(fill="both",expand=True,padx=10,pady=10)
        common=ttk.Frame(win); common.pack(fill="x",padx=12,pady=(0,8))
        batch=tk.IntVar(value=int(self.settings.get("ai_batch_size",80))); workers=tk.IntVar(value=int(self.settings.get("ai_workers",4)))
        smart_batch=tk.BooleanVar(value=bool(self.settings.get("ai_smart_batch",True)))
        file_count=tk.IntVar(value=10); visible=tk.BooleanVar(value=False)
        zip_batch_files=tk.IntVar(value=50); zip_chars=tk.IntVar(value=120000)
        ttk.Label(common,text="Макс. строк в пакете:").pack(side="left"); ttk.Spinbox(common,from_=1,to=1000,textvariable=batch,width=7).pack(side="left",padx=5)
        ttk.Label(common,text="Потоков:").pack(side="left",padx=(12,0)); ttk.Spinbox(common,from_=1,to=16,textvariable=workers,width=5).pack(side="left",padx=5)
        ttk.Checkbutton(common,text="Умные пакеты",variable=smart_batch).pack(side="left",padx=8)
        ttk.Checkbutton(common,text="Только строки текущего фильтра",variable=visible).pack(side="left",padx=8)
        ttk.Button(common,text="Остановить",command=lambda:setattr(self,"ai_cancel",True)).pack(side="right")

        # Cloud AI provider with automatic model selection
        f1=ttk.Frame(nb,padding=14); nb.add(f1,text="1. Облачный ИИ")
        provider=tk.StringVar(value=self.settings.get("ai_provider","Google Gemini"))
        env_keys={"Google Gemini":"GEMINI_API_KEY","OpenRouter":"OPENROUTER_API_KEY","Groq":"GROQ_API_KEY","OpenAI":"OPENAI_API_KEY","DeepSeek":"DEEPSEEK_API_KEY"}
        api_key=tk.StringVar(value=os.environ.get(env_keys.get(provider.get(),""),""))
        ttk.Label(f1,text="Выберите только сервис — модель программа подберёт сама.",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(f1,text="Сервис ИИ:").pack(anchor="w",pady=(14,2))
        provider_box=ttk.Combobox(f1,textvariable=provider,state="readonly",values=list(env_keys),width=32); provider_box.pack(anchor="w")
        ttk.Label(f1,text="API-ключ:").pack(anchor="w",pady=(12,2))
        key_row=ttk.Frame(f1); key_row.pack(fill="x")
        key_entry=ttk.Entry(key_row,textvariable=api_key,show="•",width=80); key_entry.pack(side="left",fill="x",expand=True)
        key_visible=tk.BooleanVar(value=False)
        def provider_changed(event=None):
            self.settings["ai_provider"]=provider.get(); self.save_settings()
            api_key.set(os.environ.get(env_keys.get(provider.get(),""),""))
        provider_box.bind("<<ComboboxSelected>>",provider_changed)
        def paste_api_key(event=None):
            try: api_key.set(win.clipboard_get().strip()); key_entry.icursor("end")
            except tk.TclError: messagebox.showwarning(APP_TITLE,"Буфер обмена пуст",parent=win)
            return "break"
        ttk.Button(key_row,text="Вставить",command=paste_api_key).pack(side="left",padx=(6,0))
        ttk.Checkbutton(key_row,text="Показать",variable=key_visible,command=lambda:key_entry.configure(show="" if key_visible.get() else "•")).pack(side="left",padx=(6,0))
        ttk.Label(f1,text="Модель выбирается автоматически; при недоступности используется резервная. OpenRouter использует бесплатный маршрутизатор.",wraplength=760).pack(anchor="w",pady=12)
        ttk.Button(f1,text="Проверить ключ",command=lambda:self.test_cloud_ai(provider.get(),api_key.get())).pack(anchor="w",pady=(0,6))
        ttk.Button(f1,text="Перевести пустые строки",style="Accent.TButton",command=lambda:self.start_ai_translation("cloud",api_key.get(),provider.get(),"",batch.get(),visible.get(),win,workers.get(),smart_batch.get())).pack(anchor="w")

        # local
        f2=ttk.Frame(nb,padding=14); nb.add(f2,text="2. Ollama / LM Studio")
        backend=tk.StringVar(value="Ollama"); endpoint=tk.StringVar(value="http://localhost:11434"); local_model=tk.StringVar(value="qwen2.5:7b")
        ttk.Label(f2,text="Бесплатный локальный перевод без отправки текста в интернет.",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(f2,text="Тип сервера:").pack(anchor="w",pady=(14,2)); ttk.Combobox(f2,textvariable=backend,state="readonly",values=["Ollama","LM Studio / OpenAI-compatible"],width=34).pack(anchor="w")
        ttk.Label(f2,text="Адрес сервера:").pack(anchor="w",pady=(10,2)); ttk.Entry(f2,textvariable=endpoint,width=70).pack(anchor="w")
        ttk.Label(f2,text="Модель:").pack(anchor="w",pady=(10,2)); ttk.Entry(f2,textvariable=local_model,width=40).pack(anchor="w")
        ttk.Label(f2,text="Для Ollama обычно: http://localhost:11434 и qwen2.5:7b. Для LM Studio обычно: http://localhost:1234/v1.",wraplength=760).pack(anchor="w",pady=12)
        ttk.Button(f2,text="Проверить соединение",command=lambda:self.test_local_ai(backend.get(),endpoint.get(),local_model.get())).pack(anchor="w",pady=(0,6))
        ttk.Button(f2,text="Перевести все пустые строки локально",command=lambda:self.start_ai_translation("ollama" if backend.get()=="Ollama" else "compatible","",local_model.get(),endpoint.get(),batch.get(),visible.get(),win,workers.get(),smart_batch.get())).pack(anchor="w")

        # manual ChatGPT
        f3=ttk.Frame(nb,padding=14); nb.add(f3,text="3. Через обычный ChatGPT")
        ttk.Label(f3,text="Без API-ключа: экспортируй пакеты, переведи их в ChatGPT и импортируй ответ.",font=("Segoe UI",11,"bold")).pack(anchor="w")
        ttk.Label(f3,text="Этот вариант не полностью автоматический, зато использует обычный чат. В папке будут инструкция и JSON-пакеты.",wraplength=760).pack(anchor="w",pady=12)
        splitrow=ttk.Frame(f3); splitrow.pack(anchor="w",pady=(2,8))
        ttk.Label(splitrow,text="Количество ZIP-пакетов:").pack(side="left")
        ttk.Spinbox(splitrow,from_=1,to=999,textvariable=file_count,width=7).pack(side="left",padx=6)
        ttk.Button(f3,text="Экспортировать обычные JSON-пакеты",command=lambda:self.export_chatgpt_batches(file_count.get(),visible.get())).pack(anchor="w",pady=4)
        ziprow=ttk.Frame(f3); ziprow.pack(anchor="w",pady=(10,4))
        ttk.Label(ziprow,text="ZIP: файлов в архиве").pack(side="left")
        ttk.Spinbox(ziprow,from_=1,to=200,textvariable=zip_batch_files,width=6).pack(side="left",padx=(6,12))
        ttk.Label(ziprow,text="макс. символов").pack(side="left")
        ttk.Spinbox(ziprow,from_=10000,to=1000000,increment=10000,textvariable=zip_chars,width=10).pack(side="left",padx=6)
        ttk.Button(f3,text="Создать ZIP-пакеты для отправки в ChatGPT",style="Accent.TButton",command=lambda:self.export_chatgpt_zip_packs(zip_batch_files.get(),zip_chars.get(),visible.get())).pack(anchor="w",pady=5)
        ttk.Label(f3,text="Уже переведённые строки и строки, состоящие преимущественно из кириллицы, в ZIP не попадут. Смешанные строки будут включены.",wraplength=760).pack(anchor="w",pady=(2,8))
        ttk.Checkbutton(f3,text="Объединить переведённые файлы обратно после окончания перевода",variable=self.merge_chatgpt_batches).pack(anchor="w",pady=4)
        ttk.Button(f3,text="Импортировать переведённый JSON",command=self.import_chatgpt_json).pack(anchor="w",pady=4)
        ttk.Label(f3,text="Важно: ChatGPT должен вернуть JSON с теми же числовыми ключами. Можно импортировать один пакет за другим.",wraplength=760).pack(anchor="w",pady=12)

        self.ai_log=tk.Text(win,height=9,wrap="word",state="disabled"); self.ai_log.pack(fill="both",expand=False,padx=12,pady=(0,10))

    def ai_log_add(self,text):
        if not hasattr(self,"ai_log") or not self.ai_log.winfo_exists(): return
        self.ai_log.config(state="normal"); self.ai_log.insert("end",text+"\n"); self.ai_log.see("end"); self.ai_log.config(state="disabled"); self.update_idletasks()

    def test_local_ai(self,backend,endpoint,model):
        try:
            if backend=="Ollama":
                url=endpoint.rstrip("/")+"/api/chat"; data=http_json(url,{"model":model,"stream":False,"messages":[{"role":"user","content":"Reply only OK"}]},timeout=60); text=data.get("message",{}).get("content","")
            else:
                url=endpoint.rstrip("/")+"/chat/completions"; data=http_json(url,{"model":model,"messages":[{"role":"user","content":"Reply only OK"}],"temperature":0},timeout=60); text=data["choices"][0]["message"]["content"]
            messagebox.showinfo(APP_TITLE,"Соединение работает. Ответ: "+text[:100])
        except Exception as e: messagebox.showerror(APP_TITLE,str(e))

    def cloud_provider_config(self,provider):
        return {
            "Google Gemini": ("gemini", ["gemini-2.5-flash", "gemini-2.5-flash-lite"]),
            "OpenRouter": ("compatible", ["openrouter/free"]),
            "Groq": ("compatible", ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"]),
            "OpenAI": ("openai", ["gpt-5-mini", "gpt-4.1-mini"]),
            "DeepSeek": ("compatible", ["deepseek-chat"]),
        }.get(provider, ("compatible", []))

    def test_cloud_ai(self,provider,key):
        if not key.strip(): messagebox.showwarning(APP_TITLE,"Введите API-ключ"); return
        try:
            result=self.request_translation("cloud",key.strip(),provider,"",[(1,"Open")])
            messagebox.showinfo(APP_TITLE,"Ключ работает. Тестовый перевод: "+str(result.get("1",""))[:100])
        except Exception as e: messagebox.showerror(APP_TITLE,str(e))

    def request_translation(self,kind,secret,model,endpoint,items):
        prompt=ai_prompt(items,self.profile_glossary())
        if kind=="cloud":
            provider=model
            mode,models=self.cloud_provider_config(provider)
            errors=[]
            for chosen in models:
                try:
                    if mode=="gemini":
                        url=f"https://generativelanguage.googleapis.com/v1beta/models/{chosen}:generateContent?key={secret}"
                        data=http_json(url,{"contents":[{"parts":[{"text":prompt}]}],"generationConfig":{"responseMimeType":"application/json","temperature":0}})
                        text=data["candidates"][0]["content"]["parts"][0]["text"]
                    elif mode=="openai":
                        data=http_json("https://api.openai.com/v1/responses",{"model":chosen,"input":prompt},headers={"Authorization":"Bearer "+secret})
                        text=data.get("output_text","")
                        if not text:
                            text="".join(c.get("text","") for out in data.get("output",[]) for c in out.get("content",[]) if c.get("type")=="output_text")
                    else:
                        base={"OpenRouter":"https://openrouter.ai/api/v1","Groq":"https://api.groq.com/openai/v1","DeepSeek":"https://api.deepseek.com/v1"}[provider]
                        headers={"Authorization":"Bearer "+secret}
                        if provider=="OpenRouter": headers.update({"HTTP-Referer":"https://localhost","X-Title":APP_TITLE})
                        data=http_json(base+"/chat/completions",{"model":chosen,"messages":[{"role":"user","content":prompt}],"temperature":0},headers=headers)
                        text=data["choices"][0]["message"]["content"]
                    return parse_json_object(text)
                except Exception as ex:
                    errors.append(f"{chosen}: {ex}")
            raise RuntimeError("Все автоматические модели недоступны:\n"+"\n".join(errors))
        elif kind=="openai":
            data=http_json("https://api.openai.com/v1/responses",{"model":model,"input":prompt},headers={"Authorization":"Bearer "+secret})
            text=data.get("output_text","")
            if not text:
                parts=[]
                for out in data.get("output",[]):
                    for c in out.get("content",[]):
                        if c.get("type")=="output_text": parts.append(c.get("text",""))
                text="".join(parts)
        elif kind=="ollama":
            data=http_json(endpoint.rstrip("/")+"/api/chat",{"model":model,"stream":False,"format":"json","messages":[{"role":"user","content":prompt}]})
            text=data.get("message",{}).get("content","")
        else:
            data=http_json(endpoint.rstrip("/")+"/chat/completions",{"model":model,"messages":[{"role":"user","content":prompt}],"temperature":0})
            text=data["choices"][0]["message"]["content"]
        return parse_json_object(text)

    def start_ai_translation(self,kind,secret,model,endpoint,batch_size,only_visible,window,workers=4,smart_batch=True):
        """Fast automatic translation with Translation Memory, adaptive packs and safe retries."""
        if self.ai_running: messagebox.showwarning(APP_TITLE,"Перевод уже выполняется"); return

        # Translation Memory всегда проверяется первой: найденные строки не расходуют
        # API-запросы и не передаются внешнему или локальному ИИ.
        candidates,tm_exact,tm_normalized,tm_rejected=self.apply_translation_memory_before_ai(only_visible)
        tm_total=tm_exact+tm_normalized
        if tm_total:
            self.ai_log_add(f"Translation Memory: применено {tm_total} (точных {tm_exact}, нормализованных {tm_normalized})")
        if tm_rejected:
            self.ai_log_add(f"Translation Memory: отклонено проверкой QA — {tm_rejected}")
        if not candidates:
            messagebox.showinfo(APP_TITLE,
                f"Все пустые строки заполнены из Translation Memory.\nПрименено: {tm_total}\nЗапросы к ИИ не выполнялись.")
            return
        if kind in ("openai","cloud") and not secret.strip():
            messagebox.showwarning(APP_TITLE,
                f"Из Translation Memory применено: {tm_total}.\nОсталось для ИИ: {len(candidates)}.\nВведите API-ключ.")
            return
        batch_size=max(1,min(1000,int(batch_size)))
        workers=max(1,min(16,int(workers)))
        # Local models normally become slower when several requests fight for one GPU.
        if kind in ("ollama","compatible") and workers>4:
            workers=4
        self.settings["ai_batch_size"]=batch_size; self.settings["ai_workers"]=workers; self.settings["ai_smart_batch"]=bool(smart_batch); self.save_settings()
        self.ai_cancel=False; self.ai_running=True

        def make_groups(entries):
            if not smart_batch:
                return [entries[i:i+batch_size] for i in range(0,len(entries),batch_size)]
            # Character-aware packing prevents oversized requests while combining many short UI strings.
            char_limit=18000 if kind=="cloud" else 10000
            groups=[]; current=[]; chars=0
            for e in entries:
                cost=len(e.source_text)+24
                if current and (len(current)>=batch_size or chars+cost>char_limit):
                    groups.append(current); current=[]; chars=0
                current.append(e); chars+=cost
            if current: groups.append(current)
            return groups

        groups=make_groups(candidates)
        self.ai_log_add(f"Начато ИИ: {len(candidates)} строк; из памяти: {tm_total}; пакетов: {len(groups)}; потоков: {workers}; умные пакеты: {'да' if smart_batch else 'нет'}")

        def worker():
            counters={"done":0,"failed":0,"packs":0}; lock=threading.Lock()

            def translate_group(group,depth=0):
                if self.ai_cancel: return
                indexed=list(enumerate((e.source_text for e in group),start=1))
                last_error=None
                # Two attempts for temporary network/rate-limit failures.
                for attempt in range(2):
                    if self.ai_cancel: return
                    try:
                        result=self.request_translation(kind,secret.strip(),model.strip(),endpoint.strip(),indexed)
                        local_done=local_failed=0
                        for i,e in enumerate(group,start=1):
                            t=str(result.get(str(i),"")).strip()
                            if t and not validate_translation(e.source_text,t):
                                e.translation=t; e.status="translated"; local_done+=1
                                try: self.tmdb.put(e.source_text,t,verified=False)
                                except Exception: pass
                            else: local_failed+=1
                        with lock:
                            counters["done"]+=local_done; counters["failed"]+=local_failed; counters["packs"]+=1
                            d,f,p=counters["done"],counters["failed"],counters["packs"]
                        self.after(0,lambda d=d,f=f,p=p:self.ai_log_add(f"Пакетов {p}/{len(groups)} · переведено {d} · ошибок {f}"))
                        return
                    except Exception as ex:
                        last_error=ex
                        if attempt==0: time.sleep(1.5)
                # If a large pack failed, split it automatically instead of losing all its strings.
                if len(group)>1 and depth<6 and not self.ai_cancel:
                    mid=len(group)//2
                    self.after(0,lambda n=len(group):self.ai_log_add(f"Пакет из {n} строк разделён после ошибки"))
                    translate_group(group[:mid],depth+1); translate_group(group[mid:],depth+1)
                else:
                    with lock: counters["failed"]+=len(group)
                    self.after(0,lambda ex=last_error:self.ai_log_add("Ошибка строки/пакета: "+str(ex)))

            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix="translator") as pool:
                    futures=[pool.submit(translate_group,g) for g in groups]
                    for future in concurrent.futures.as_completed(futures):
                        if self.ai_cancel:
                            for f in futures: f.cancel()
                            break
                        try: future.result()
                        except Exception as ex: self.after(0,lambda ex=ex:self.ai_log_add("Ошибка потока: "+str(ex)))
                        self.dirty=True
                        self.after(0,self.refresh); self.after(0,self.save_table)
                done,failed=counters["done"],counters["failed"]
                msg=(f"Перевод остановлен. Готово: {done}; ошибок: {failed}" if self.ai_cancel else
                     f"Автоперевод завершён. Переведено: {done}; ошибок/пропусков: {failed}")
                self.after(0,lambda msg=msg:messagebox.showinfo(APP_TITLE,msg))
            finally:
                self.ai_running=False; self.after(0,self.refresh)
        threading.Thread(target=worker,daemon=True).start()

    def export_chatgpt_batches(self,file_count,only_visible):
        """Создаёт отдельный ZIP для каждого пакета ChatGPT; уже переведённые строки не экспортируются."""
        items=self.ai_candidates(only_visible)
        if not items:
            messagebox.showinfo(APP_TITLE,"Нет непереведённых строк для экспорта")
            return
        raw_folder=filedialog.askdirectory(title="Куда сохранить ZIP-пакеты ChatGPT")
        if not raw_folder:return
        folder=Path(raw_folder); folder.mkdir(parents=True,exist_ok=True)
        wanted=max(1,min(int(file_count),len(items)))
        base,extra=divmod(len(items),wanted)
        session_id=datetime.now().strftime("%Y%m%d_%H%M%S")
        session_folder=folder/f"ChatGPT_Packs_{session_id}"
        session_folder.mkdir(parents=True,exist_ok=True)
        master_manifest={"format_version":2,"created_at":datetime.now().isoformat(timespec="seconds"),"total_packs":wanted,"total_strings":len(items),"packs":{}}
        pos=0; created=[]
        instruction=ai_prompt([(1,"EXAMPLE TEXT")],self.profile_glossary()).split("INPUT JSON:")[0]+"""

ИНСТРУКЦИЯ:
1. Переведи только значения поля text.
2. Не меняй числовые ключи, file, line, context и category.
3. Верни один корректный JSON-объект, где каждый числовой ключ содержит строку перевода.
4. Сохрани результат под именем translated_batch_XXXX.json.
5. Уже переведённые строки сюда не включены программой.
"""
        for n in range(1,wanted+1):
            size=base+(1 if n<=extra else 0); group=items[pos:pos+size]; pos+=size
            batch_name=f"batch_{n:04d}.json"
            translated_name=f"translated_batch_{n:04d}.json"
            payload={}
            ids=[]
            for i,e in enumerate(group,start=1):
                payload[str(i)]={"text":e.source_text,"file":e.file,"line":e.line,"context":e.context,"category":self.settings.get("profile","Общий")} if self.settings.get("context_export",True) else e.source_text
                ids.append(e.id)
            pack_manifest={
                "format_version":2,"pack":n,"total_packs":wanted,"source_batch":batch_name,
                "expected_translation":translated_name,"strings":len(group),"entry_ids":ids,
                "note":"Already translated and protected entries were skipped."
            }
            with tempfile.TemporaryDirectory(prefix="chatgpt_pack_") as td:
                work=Path(td)
                (work/batch_name).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
                (work/"manifest.json").write_text(json.dumps({batch_name:ids,"meta":pack_manifest},ensure_ascii=False,indent=2),encoding="utf-8")
                (work/"INSTRUCTION_RU.txt").write_text(instruction,encoding="utf-8")
                zip_path=session_folder/f"ChatGPT_Pack_{n:04d}_of_{wanted:04d}.zip"
                zip_contents(work,zip_path)
            master_manifest["packs"][zip_path.name]=pack_manifest
            created.append(zip_path)
        (session_folder/"master_manifest.json").write_text(json.dumps(master_manifest,ensure_ascii=False,indent=2),encoding="utf-8")
        messagebox.showinfo(APP_TITLE,f"Готово. Создано ZIP-пакетов: {len(created)}\nНепереведённых строк: {len(items)}\nПапка: {session_folder}")

    def export_chatgpt_zip_packs(self, files_per_zip=50, max_chars=120000, only_visible=False):
        """Умная подготовка ZIP-пакетов для ChatGPT (версия 8.0).

        Перед экспортом подставляет точные совпадения из Translation Memory, пропускает
        уже переведённые/защищённые/русские строки и объединяет одинаковые исходники.
        """
        try:
            files_per_zip=max(1,min(200,int(files_per_zip)))
            max_chars=max(10000,min(1000000,int(max_chars)))
        except (TypeError,ValueError,tk.TclError):
            messagebox.showerror(APP_TITLE,"Количество JSON и лимит символов должны быть целыми числами.")
            return

        def language_state(text):
            letters=[c for c in text if c.isalpha()]
            if not letters:return "nontext"
            cyr=sum(('А'<=c<='я') or c in 'ЁёІіЇїЄєҐґ' for c in letters)
            lat=sum(('A'<=c<='Z') or ('a'<=c<='z') for c in letters)
            if cyr and not lat:return "cyrillic"
            if cyr/len(letters)>=0.70 and lat/len(letters)<0.15:return "cyrillic"
            if cyr and lat:return "mixed"
            return "latin"

        base=list(self.visible if only_visible else self.entries)
        stats={"protected":0,"already_translated":0,"cyrillic":0,"empty_or_nontext":0,
               "from_memory":0,"duplicates_removed":0}
        candidates=[]
        seen={}
        for e in base:
            if e.protected=="yes":stats["protected"]+=1;continue
            if e.translation.strip():stats["already_translated"]+=1;continue
            src=e.source_text.strip()
            if not src or language_state(src)=="nontext":stats["empty_or_nontext"]+=1;continue
            if language_state(src)=="cyrillic":stats["cyrillic"]+=1;continue
            if self.settings.get("memory_enabled",True):
                mt,_=self.tmdb.lookup(e.source_text,self.settings.get("normalized_memory",True))
                if mt and not validate_translation(e.source_text,mt):
                    e.translation=mt;e.status="translated";stats["from_memory"]+=1;self.dirty=True;continue
            key=normalize_memory_key(e.source_text)
            if key in seen:
                stats["duplicates_removed"]+=1
                seen[key]["ids"].append(e.id)
                continue
            rec={"entry":e,"ids":[e.id]};seen[key]=rec;candidates.append(rec)

        if stats["from_memory"]:
            self.refresh();self.save_table()
        if not candidates:
            messagebox.showinfo(APP_TITLE,"Нет новых строк для экспорта. Все строки уже переведены, защищены, русские или найдены в памяти переводов.")
            return

        raw_folder=filedialog.askdirectory(title="Куда сохранить ZIP-пакеты ChatGPT 8.0")
        if not raw_folder:return
        root=Path(raw_folder);session_id=datetime.now().strftime("%Y%m%d_%H%M%S")
        session_folder=root/f"ChatGPT_8_Packs_{session_id}";session_folder.mkdir(parents=True,exist_ok=True)

        # Умный размер: не более 150 строк и примерно 24 000 символов в одном JSON.
        per_json_chars=min(24000,max(8000,max_chars//max(1,min(files_per_zip,6))))
        groups=[];cur=[];cur_chars=0
        for rec in candidates:
            e=rec["entry"];cost=len(e.source_text)+len(e.file or "")+len(e.context or "")+160
            if cur and (len(cur)>=150 or cur_chars+cost>per_json_chars):groups.append(cur);cur=[];cur_chars=0
            cur.append(rec);cur_chars+=cost
        if cur:groups.append(cur)

        zip_groups=[];zc=[];zchars=0;zstrings=0
        for group in groups:
            gc=sum(len(r["entry"].source_text)+len(r["entry"].file or "")+len(r["entry"].context or "")+160 for r in group)
            if zc and (len(zc)>=files_per_zip or zchars+gc>max_chars or zstrings+len(group)>500):
                zip_groups.append(zc);zc=[];zchars=0;zstrings=0
            zc.append(group);zchars+=gc;zstrings+=len(group)
        if zc:zip_groups.append(zc)

        instruction=("ИНСТРУКЦИЯ ДЛЯ CHATGPT — GMLS 8.0\n=====================================\n\n"
          "Переведи на русский язык только значения поля text. Не меняй ключи, file, line, context, category, placeholders, теги и \n. "
          "Для каждого batch_XXXX.json верни translated_batch_XXXX.json в виде {\"1\": \"перевод\"}. "
          "Русские, уже переведённые и найденные в памяти строки сюда не включены.\n")
        master={"format_version":4,"app_version":"8.0","created_at":datetime.now().isoformat(timespec="seconds"),
                "total_archives":len(zip_groups),"total_json_batches":len(groups),"total_unique_strings":len(candidates),
                "statistics":stats,"limits":{"json_files_per_zip":files_per_zip,"max_characters_per_zip":max_chars,"max_strings_per_zip":500},"archives":[]}
        global_batch=0
        for ano,agroups in enumerate(zip_groups,1):
            aman={"format_version":4,"app_version":"8.0","meta":{},"batches":{}}
            achars=0
            with tempfile.TemporaryDirectory(prefix="gmls8_") as td:
                work=Path(td)
                for group in agroups:
                    global_batch+=1;bn=f"batch_{global_batch:04d}.json";tn=f"translated_batch_{global_batch:04d}.json"
                    payload={};mapping={}
                    for i,rec in enumerate(group,1):
                        e=rec["entry"]
                        payload[str(i)]={"text":e.source_text,"file":e.file,"line":e.line,"context":e.context,"category":self.settings.get("profile","Общий")} if self.settings.get("context_export",True) else e.source_text
                        mapping[str(i)]=rec["ids"]
                    txt=json.dumps(payload,ensure_ascii=False,indent=2);(work/bn).write_text(txt,encoding="utf-8");achars+=len(txt)
                    aman[bn]=[ids[0] for ids in mapping.values()]  # совместимость со старыми импортёрами
                    aman["batches"][bn]={"expected_translation":tn,"strings":len(group),"entry_ids_by_key":mapping}
                aman["meta"]={"archive":ano,"total_archives":len(zip_groups),"json_files":len(agroups),"characters":achars,"strings":sum(map(len,agroups))}
                (work/"manifest.json").write_text(json.dumps(aman,ensure_ascii=False,indent=2),encoding="utf-8")
                (work/"INSTRUCTION_RU.txt").write_text(instruction,encoding="utf-8")
                zp=session_folder/f"ChatGPT_Pack_{ano:03d}_of_{len(zip_groups):03d}.zip";zip_contents(work,zp)
                master["archives"].append({"file":zp.name,"json_files":len(agroups),"strings":sum(map(len,agroups)),"characters":achars})
        (session_folder/"master_manifest.json").write_text(json.dumps(master,ensure_ascii=False,indent=2),encoding="utf-8")
        report=(f"GMLS 8.0 — ОТЧЁТ ПОДГОТОВКИ\nАрхивов: {len(zip_groups)}\nJSON: {len(groups)}\nНовых уникальных строк: {len(candidates)}\n"
                f"Из памяти: {stats['from_memory']}\nУже переведено: {stats['already_translated']}\nРусских пропущено: {stats['cyrillic']}\n"
                f"Дубликатов убрано: {stats['duplicates_removed']}\nЗащищённых: {stats['protected']}\n")
        (session_folder/"EXPORT_REPORT_RU.txt").write_text(report,encoding="utf-8")
        messagebox.showinfo(APP_TITLE,report+f"\nПапка: {session_folder}")

    def import_chatgpt_json(self):
        paths=filedialog.askopenfilenames(filetypes=[("JSON","*.json")])
        if not paths:return
        count=0; by_id={e.id:e for e in self.entries}
        for raw in paths:
            p=Path(raw); folder=p.parent; manifest_path=folder/"manifest.json"
            if not manifest_path.exists(): messagebox.showwarning(APP_TITLE,f"Рядом с {p.name} нет manifest.json"); continue
            manifest=json.loads(manifest_path.read_text(encoding="utf-8")); original_name=p.name.replace("translated_","")
            batch_meta=(manifest.get("batches") or {}).get(original_name,{})
            mapping=batch_meta.get("entry_ids_by_key")
            ids=manifest.get(original_name) or manifest.get(p.name)
            if not mapping and not ids: messagebox.showwarning(APP_TITLE,f"Пакет {p.name} не найден в manifest.json"); continue
            data=parse_json_object(p.read_text(encoding="utf-8"))
            if mapping:
                iterable=[(str(k),v if isinstance(v,list) else [v]) for k,v in mapping.items()]
            else:
                iterable=[(str(i),[eid]) for i,eid in enumerate(ids,start=1)]
            for key,eids in iterable:
                raw_value=data.get(key,"")
                if isinstance(raw_value,dict): raw_value=raw_value.get("translation") or raw_value.get("text") or ""
                t=str(raw_value).strip()
                for eid in eids:
                    e=by_id.get(eid)
                    if e and t and not validate_translation(e.source_text,t): e.translation=t;e.status="translated";count+=1
        self.dirty|=bool(count)
        if count and self.settings.get("memory_enabled",True):
            self.tmdb.add_many(self.entries,Path(self.source.get()).name if self.source.get() else "")
        self.refresh();self.save_table()
        merged_path=None
        if self.merge_chatgpt_batches.get() and paths:
            merged={e.id:e.translation for e in self.entries if e.translation.strip()}
            merged_path=Path(paths[0]).parent/"merged_translations.json"
            merged_path.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding="utf-8")
        msg=f"Импортировано переводов: {count}"
        if merged_path: msg+=f"\nОбъединённый файл: {merged_path.name}"
        messagebox.showinfo(APP_TITLE,msg)


    def project_library_path(self):
        return Path.cwd() / PROJECT_LIBRARY_FILE

    def load_project_library(self):
        p = self.project_library_path()
        try:
            data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_project_library(self, data):
        self.project_library_path().write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def register_current_project(self):
        if not self.project_path:
            return
        items = self.load_project_library()
        key = str(self.project_path.resolve())
        row = {
            "project": key,
            "game": self.game.get(),
            "source": self.source.get(),
            "table": self.table.get(),
            "output": self.output.get(),
            "name": self.project_path.stem,
            "entries": len(self.entries),
            "translated": sum(bool(e.translation.strip()) for e in self.entries),
            "updated": datetime.now().isoformat(timespec="seconds"),
        }
        items = [x for x in items if x.get("project") != key]
        items.append(row)
        items = sorted(items, key=lambda x: x.get("updated", ""), reverse=True)[:200]
        self.save_project_library(items)

    def source_localization_analysis(self):
        src = Path(self.source.get().strip())
        if not src.exists():
            raise ValueError("Выберите исходный мод или ZIP")
        with tempfile.TemporaryDirectory(prefix="pzloc_analysis_") as td:
            root = prepare_source(src, Path(td))
            detected=detect_game_structure(root)
            if detected and detected!=self.game.get():
                return {"status":"Нужна ручная проверка","confidence":"high","reason":f"Выбран профиль {self.game.get()}, но обнаружена структура {detected}","english_strings":0,"cyrillic_strings":0,"files":0,"russian_folders":0,"parse_failures":0}
            if self.game.get()==GAME_RW:
                entries=extract_rimworld_entries(root)
                return {"status":("Перевод требуется" if entries else "Локализуемый текст не найден"),"confidence":"high","reason":"Проверены Languages/English и переводимые поля Defs","english_strings":len(entries),"cyrillic_strings":0,"files":len({e.file for e in entries}),"russian_folders":sum(1 for p in root.rglob("Russian") if p.is_dir()),"parse_failures":0}
            return count_scripts_and_languages(root)

    def check_translation_need(self):
        try:
            a = self.source_localization_analysis()
        except Exception as e:
            messagebox.showerror(APP_TITLE, str(e))
            return
        details = (
            f"Результат: {a['status']}\n"
            f"Уверенность: {a['confidence']}\n\n"
            f"{a['reason']}\n\n"
            f"Всего файлов: {a['total_files']}\n"
            f"Поддерживаемых текстовых файлов: {a['text_files']}\n"
            f"Английских пользовательских строк: {a['english_strings']}\n"
            f"Кириллических строк: {a['cyrillic_strings']}\n"
            f"Каталогов/файлов русской локализации: {a['ru_paths']}\n"
        )
        if a["parse_errors"]:
            details += "\nОшибки чтения:\n- " + "\n- ".join(a["parse_errors"])
        details += "\n\nВажно: результат является безопасной оценкой. Нестандартный Lua-код может создавать текст во время игры."
        messagebox.showinfo("Проверка необходимости перевода", details)
        self.status.set(a["status"])

    def merge_packages_dialog(self):
        paths = filedialog.askopenfilenames(
            title="Выберите ZIP-пакеты русификаторов",
            filetypes=[("ZIP", "*.zip")],
        )
        if len(paths) < 2:
            messagebox.showwarning(APP_TITLE, "Выберите не менее двух ZIP-пакетов русификаторов.")
            return
        win = tk.Toplevel(self)
        win.title("Создание общего русификатора")
        win.geometry("620x310")
        win.transient(self)
        name = tk.StringVar(value="Мой общий русификатор")
        mid = tk.StringVar(value="My_Russian_Translation_Pack")
        out = tk.StringVar(value=self.output.get())
        frm = ttk.Frame(win, padding=18)
        frm.pack(fill="both", expand=True)
        frm.columnconfigure(1, weight=1)
        ttk.Label(frm, text=f"Выбрано пакетов: {len(paths)}", font=("Segoe UI Semibold", 12)).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 14))
        for r, (lab, var) in enumerate((("Название", name), ("ID общего мода", mid), ("Папка результата", out)), start=1):
            ttk.Label(frm, text=lab).grid(row=r, column=0, sticky="w", pady=7)
            ttk.Entry(frm, textvariable=var).grid(row=r, column=1, sticky="ew", padx=8, pady=7)
        def choose_output():
            selected = filedialog.askdirectory()
            if selected:
                out.set(selected)
        ttk.Button(frm, text="Выбрать", command=choose_output).grid(row=3, column=2)

        def go():
            try:
                if not name.get().strip() or not mid.get().strip():
                    raise ValueError("Укажите название и ID")
                result = merge_translation_packages(paths, Path(out.get()), name.get().strip(), mid.get().strip())
                if not result["ok"]:
                    report = "Сборка остановлена. Обнаружены конфликты файлов:\n- " + "\n- ".join(result["conflicts"][:100])
                    messagebox.showerror(APP_TITLE, report)
                    return
                win.destroy()
                messagebox.showinfo(
                    APP_TITLE,
                    f"Общий русификатор создан.\nФайлов объединено: {result['copied']}\n"
                    f"Исходных модов: {len(result['sources'])}\nZIP: {result['zip']}",
                )
            except Exception as e:
                messagebox.showerror(APP_TITLE, str(e))

        ttk.Label(
            frm,
            text="Оригинальные ZIP не изменяются. При конфликте разных файлов сборка будет остановлена.",
            wraplength=540,
        ).grid(row=4, column=0, columnspan=3, sticky="w", pady=14)
        ttk.Button(frm, text="Проверить и создать", style="Good.TButton", command=go).grid(row=5, column=1, sticky="e")

    def open_project_manager(self):
        win = tk.Toplevel(self)
        win.title("Менеджер проектов и пакетов")
        win.geometry("900x570")
        win.transient(self)
        outer = ttk.Frame(win, padding=12)
        outer.pack(fill="both", expand=True)
        cols = ("name", "updated", "entries", "translated", "source")
        tree = ttk.Treeview(outer, columns=cols, show="headings")
        for c, t, w in (
            ("name", "Проект", 180),
            ("updated", "Обновлён", 150),
            ("entries", "Строк", 70),
            ("translated", "Переведено", 90),
            ("source", "Исходный мод", 350),
        ):
            tree.heading(c, text=t)
            tree.column(c, width=w, anchor="w")
        tree.pack(fill="both", expand=True)
        items = self.load_project_library()
        for i, x in enumerate(items):
            tree.insert("", "end", iid=str(i), values=(x.get("name", ""), x.get("updated", ""), x.get("entries", 0), x.get("translated", 0), x.get("source", "")))
        bar = ttk.Frame(outer)
        bar.pack(fill="x", pady=(10, 0))

        def open_sel():
            sel = tree.selection()
            if not sel:
                return
            path = Path(items[int(sel[0])].get("project", ""))
            if not path.exists():
                messagebox.showerror(APP_TITLE, "Файл проекта не найден")
                return
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self.project_path = path
                self.source.set(data.get("source", ""))
                self.table.set(data.get("table", ""))
                self.output.set(data.get("output", str(Path.cwd() / "output")))
                if Path(self.table.get()).exists():
                    self.load_table(Path(self.table.get()))
                win.destroy()
            except Exception as e:
                messagebox.showerror(APP_TITLE, str(e))

        ttk.Button(bar, text="Открыть выбранный", command=open_sel).pack(side="left")
        ttk.Button(bar, text="Создать общий русификатор из ZIP", style="Good.TButton", command=self.merge_packages_dialog).pack(side="left", padx=8)
        ttk.Button(bar, text="Проверить текущий мод", command=self.check_translation_need).pack(side="left")
        ttk.Button(bar, text="Закрыть", command=win.destroy).pack(side="right")

    def analyze_project(self):
        untranslated=[e for e in self.entries if e.protected!='yes' and not e.translation.strip()]
        issues=self.collect_qa(); dangerous=sorted({e.file for e in self.entries if e.translation.strip() and e.file.lower().endswith('.lua')})
        duplicates={}
        for e in self.entries:duplicates.setdefault(normalize_memory_key(e.source_text),[]).append(e)
        near_duplicates=sum(1 for v in duplicates.values() if len(v)>1)
        return {"total":len(self.entries),"translated":sum(bool(e.translation.strip()) for e in self.entries),"untranslated":len(untranslated),"issues":len(issues),"lua_files":dangerous,"duplicates":near_duplicates}

    def preview_build(self):
        if not self.entries:messagebox.showwarning(APP_TITLE,'Сначала просканируйте мод');return
        a=self.analyze_project(); win=tk.Toplevel(self);win.title('Предпросмотр сборки');win.geometry('760x560');win.transient(self)
        text=tk.Text(win,wrap='word',padx=14,pady=14);text.pack(fill='both',expand=True,padx=10,pady=10)
        report=(f"ПРЕДПРОСМОТР СБОРКИ\n\nВсего строк: {a['total']}\nПереведено: {a['translated']}\nНе переведено: {a['untranslated']}\nПроблем QA: {a['issues']}\nПовторяющихся нормализованных строк: {a['duplicates']}\nФайлов Lua с переводами: {len(a['lua_files'])}\n\n")
        if a['lua_files']:report+='Файлы Lua требуют проверки в игре:\n- '+'\n- '.join(a['lua_files'][:80])+'\n'
        report+='\nИтоговый ZIP будет содержать папки модов прямо в корне и готов к распаковке в Zomboid\\mods.'
        text.insert('1.0',report);text.config(state='disabled')
        bar=ttk.Frame(win);bar.pack(fill='x',padx=10,pady=(0,10));ttk.Button(bar,text='Закрыть',command=win.destroy).pack(side='right');ttk.Button(bar,text='Создать русификатор',style='Good.TButton',command=lambda:(win.destroy(),self.build())).pack(side='right',padx=8)

    def open_smart_tools(self):
        win=tk.Toplevel(self);win.title('Умные инструменты');win.geometry('820x600');win.transient(self)
        nb=ttk.Notebook(win);nb.pack(fill='both',expand=True,padx=10,pady=10)
        mem=ttk.Frame(nb,padding=16);nb.add(mem,text='Память переводов')
        count,verified,size=self.tmdb.stats();info=tk.StringVar(value=f'Записей: {count}   Проверенных: {verified}   Размер: {size/1024/1024:.2f} МБ')
        ttk.Label(mem,text='Локальная библиотека SQLite',font=('Segoe UI Semibold',13)).pack(anchor='w');ttk.Label(mem,textvariable=info).pack(anchor='w',pady=(5,14))
        enabled=tk.BooleanVar(value=self.settings.get('memory_enabled',True));norm=tk.BooleanVar(value=self.settings.get('normalized_memory',True))
        ttk.Checkbutton(mem,text='Использовать память автоматически',variable=enabled).pack(anchor='w',pady=4);ttk.Checkbutton(mem,text='Разрешить нормализованные совпадения',variable=norm).pack(anchor='w',pady=4)
        row=ttk.Frame(mem);row.pack(anchor='w',pady=14);ttk.Button(row,text='Импорт',command=self.import_memory).pack(side='left');ttk.Button(row,text='Экспорт',command=self.export_memory).pack(side='left',padx=6);ttk.Button(row,text='Менеджер',command=self.open_translation_memory_manager).pack(side='left',padx=6)
        def clear_db():
            if messagebox.askyesno(APP_TITLE,'Очистить всю библиотеку переводов?'):self.tmdb.clear();info.set('Записей: 0   Проверенных: 0   Размер базы будет освобождён после следующего запуска')
        ttk.Button(row,text='Очистить',command=clear_db).pack(side='left')
        settings=ttk.Frame(nb,padding=16);nb.add(settings,text='Настройки')
        ttk.Label(settings,text='Профиль терминологии').grid(row=0,column=0,sticky='w',pady=8);profile=tk.StringVar(value=self.settings.get('profile','Общий'));ttk.Combobox(settings,textvariable=profile,values=list(PROFILE_TERMS),state='readonly',width=28).grid(row=0,column=1,sticky='w',padx=10)
        context=tk.BooleanVar(value=self.settings.get('context_export',True));snap=tk.BooleanVar(value=self.settings.get('auto_snapshot',True));ratio=tk.DoubleVar(value=float(self.settings.get('length_ratio',2.4)))
        ttk.Checkbutton(settings,text='Добавлять контекст в пакеты ChatGPT',variable=context).grid(row=1,column=0,columnspan=2,sticky='w',pady=7)
        ttk.Checkbutton(settings,text='Создавать резервные копии автоматически',variable=snap).grid(row=2,column=0,columnspan=2,sticky='w',pady=7)
        ttk.Label(settings,text='Предупреждать, если перевод длиннее оригинала более чем в (раз):').grid(row=3,column=0,sticky='w',pady=8);ttk.Spinbox(settings,from_=1.2,to=5.0,increment=.1,textvariable=ratio,width=8).grid(row=3,column=1,sticky='w',padx=10)
        analysis=ttk.Frame(nb,padding=16);nb.add(analysis,text='Анализ проекта');a=self.analyze_project();ttk.Label(analysis,text=f"Строк: {a['total']}\nПереведено: {a['translated']}\nОсталось: {a['untranslated']}\nПроблем QA: {a['issues']}\nLua-файлов с переводами: {len(a['lua_files'])}",font=('Segoe UI',11),justify='left').pack(anchor='w')
        ttk.Button(analysis,text='Найти похожий перевод',command=self.show_suggestions).pack(anchor='w',pady=(16,5));ttk.Button(analysis,text='Применить словарь',command=self.apply_glossary).pack(anchor='w',pady=5);ttk.Button(analysis,text='Предпросмотр сборки',command=self.preview_build).pack(anchor='w',pady=5);ttk.Button(analysis,text='Восстановить резервную копию',command=self.restore_snapshot).pack(anchor='w',pady=5)
        ttk.Button(analysis,text='Проверить, нужен ли перевод',command=self.check_translation_need).pack(anchor='w',pady=5)
        ttk.Button(analysis,text='Менеджер проектов и общих пакетов',command=self.open_project_manager).pack(anchor='w',pady=5)
        def save_close():
            try: length_ratio=float(ratio.get())
            except (tk.TclError,TypeError,ValueError): length_ratio=2.4
            self.settings.update(memory_enabled=enabled.get(),normalized_memory=norm.get(),profile=profile.get(),context_export=context.get(),auto_snapshot=snap.get(),length_ratio=length_ratio,theme_dark=self.theme_dark);self.save_settings();win.destroy();self.status.set('Настройки сохранены')
        ttk.Button(win,text='Сохранить настройки',style='Accent.TButton',command=save_close).pack(pady=(0,12))

    def build(self):
        src=Path(self.source.get().strip());out=Path(self.output.get().strip())
        if not src.exists():messagebox.showwarning(APP_TITLE,"Выберите исходный мод или ZIP с модами");return
        if self.dirty:self.save_table()
        self.create_snapshot("before_build")
        untranslated=[e for e in self.entries if e.protected!="yes" and not e.translation.strip()]
        bad=[e for e in self.entries if e.translation and entry_issue(e)]
        if bad:
            self.filter.set("С ошибками");self.refresh()
            messagebox.showerror(APP_TITLE,f"Сборка остановлена: найдено ошибок переменных/тегов: {len(bad)}. Откройте фильтр «С ошибками».")
            return
        if untranslated and not messagebox.askyesno(APP_TITLE,f"Не переведено {len(untranslated)} строк. Собрать русификатор только из готовых переводов?\n\nПропущенные строки попадут в отчёт."):
            self.filter.set("Не переведено");self.refresh();return
        def work():
            trans=translation_map(self.entries)
            if not trans:raise ValueError("Нет заполненных переводов")
            out.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryDirectory(prefix="gmls_build_") as td:
                prepared=prepare_source(src,Path(td))
                detected=detect_game_structure(prepared)
                if detected and detected!=self.game.get():raise ValueError(f"Несоответствие игры: выбран профиль {self.game.get()}, обнаружена структура {detected}")
                if self.game.get()==GAME_RW:
                    package,zp,repls=build_rimworld_translation(prepared,out,self.entries,src.stem)
                    self.export_memory_silent();self.register_current_project()
                    report={"date":datetime.now().isoformat(timespec="seconds"),"game":GAME_RW,"source":str(src),"translated_entries":repls,"package":str(package),"zip":str(zp)}
                    (out/"build_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
                    return f"Готово: создан перевод RimWorld. Переведено строк: {repls}.\nZIP: {zp.name}"
            out.mkdir(parents=True,exist_ok=True)
            install_root=out/"mods"
            if install_root.exists():shutil.rmtree(install_root)
            install_root.mkdir(parents=True,exist_ok=True)
            total_changed=total_repls=0; built=[]; all_changed=[]; mod_details=[]; used_folders=set(); used_ids=set()
            with tempfile.TemporaryDirectory(prefix="pzloc_patch_") as td:
                root=prepare_source(src,Path(td))
                for index,mod_root in enumerate(find_mod_roots(root),start=1):
                    package_root, content_rel = detect_mod_layout(mod_root)
                    original_info=read_mod_info(mod_root)
                    original_name=original_info.get("name") or package_root.name or mod_root.name or f"Mod_{index}"
                    original_id=original_info.get("id") or unique_safe_id(package_root.name)
                    base_folder=safe_mod_name(original_id)+"_RU"
                    folder_name=base_folder; suffix=2
                    while folder_name.lower() in used_folders:
                        folder_name=f"{base_folder}_{suffix}"; suffix+=1
                    used_folders.add(folder_name.lower())
                    patch_root=install_root/folder_name
                    content_root=patch_root/content_rel
                    # Process the whole package so Build 42 "common" files are included too.
                    changed,repls,files=apply_translations_to_patch(package_root,patch_root,trans)
                    if not changed:
                        if patch_root.exists():shutil.rmtree(patch_root)
                        continue
                    base_mod_id=unique_safe_id(original_id)+"_RU"
                    mod_id=base_mod_id; suffix=2
                    while mod_id.lower() in used_ids:
                        mod_id=f"{base_mod_id}_{suffix}"; suffix+=1
                    used_ids.add(mod_id.lower())
                    poster=copy_poster_for_layout(mod_root,content_root)
                    info=(
                        f"name={original_name} — Русский перевод\n"
                        f"id={mod_id}\n"
                        f"description=Русский перевод для {original_name}. Включите после оригинального мода.\n"
                        f"poster={poster}\n"
                        f"require={original_id}\n"
                    )
                    (content_root/"mod.info").write_text(info,encoding="utf-8")
                    total_changed+=changed;total_repls+=repls;built.append(folder_name)
                    prefix=Path(folder_name).as_posix()
                    all_changed.extend(f"{prefix}/{x}" for x in files)
                    mod_details.append({"original_name":original_name,"original_id":original_id,"translation_id":mod_id,"folder":folder_name,"layout":content_rel.as_posix() or "root","changed_files":changed,"replacements":repls})
            if not built:raise ValueError("Не найдено файлов, в которых можно применить заполненные переводы")
            readme=(
                "УСТАНОВКА РУСИФИКАТОРА PROJECT ZOMBOID\n"
                "========================================\n\n"
                "Архив уже подготовлен для папки Zomboid\\mods.\n"
                "Откройте архив и перенесите все папки из него прямо в:\n"
                "C:\\Users\\<имя>\\Zomboid\\mods\n\n"
                "В игре включите оригинальные моды, затем русификаторы.\n"
                "Зависимость require уже добавлена автоматически.\n"
                "Важно: некоторые моды содержат жёстко записанный текст в Lua. Для них русификатор является патчем файлов; проверяйте работу в игре после обновления оригинального мода.\n\n"
                "Созданные русификаторы:\n- "+"\n- ".join(built)+"\n"
            )
            (install_root/"README_УСТАНОВКА.txt").write_text(readme,encoding="utf-8")
            zp=out/"PZ_Russian_Translation_Install.zip"
            if zp.exists():zp.unlink()
            zip_contents(install_root,zp)
            self.export_memory_silent(); self.register_current_project()
            skipped=len(untranslated); protected=sum(e.protected=="yes" for e in self.entries)
            translated_count=sum(1 for e in self.entries if e.protected!="yes" and e.translation.strip() and e.translation.strip()!=e.source_text)
            report={"date":datetime.now().isoformat(timespec="seconds"),"source":str(src),"total_entries":len(self.entries),"translated_entries":translated_count,"untranslated_entries":skipped,"protected_entries":protected,"qa_errors":0,"replacements":total_repls,"changed_files":total_changed,"created_mods":built,"mods":mod_details,"files":all_changed}
            (out/"build_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
            missing_lines=[f"- {e.source_text} [{e.file}:{e.line}]" for e in untranslated[:1000]]
            report_txt=(
                "ОТЧЁТ О СБОРКЕ РУСИФИКАТОРА\n"
                "================================\n"
                f"Всего строк: {len(self.entries)}\nПереведено: {translated_count}\nПропущено: {skipped}\nЗащищено: {protected}\nОшибок QA: 0\n"
                f"Создано русификаторов: {len(built)}\nИзменено файлов: {total_changed}\nВыполнено замен: {total_repls}\n\n"
                "Непереведённые строки:\n"+("\n".join(missing_lines) if missing_lines else "нет")+"\n"
            )
            (out/"build_report.txt").write_text(report_txt,encoding="utf-8")
            return f"Готово: создано русификаторов {len(built)}, замен {total_repls}, файлов {total_changed}. Пропущено строк: {skipped}.\nZIP можно распаковать прямо в Zomboid\\mods."
        self.run("Сборка русификатора…",work)
    def export_memory_silent(self):
        mem=self.load_memory_file();mem.update(translation_map(self.entries));self.memory_path().write_text(json.dumps(mem,ensure_ascii=False,indent=2),encoding="utf-8")
        self.tmdb.add_many(self.entries,Path(self.source.get()).name if self.source.get() else "")
    def open_output(self):
        p=Path(self.output.get());p.mkdir(parents=True,exist_ok=True)
        try:
            if sys.platform.startswith("win"):os.startfile(str(p))
            elif sys.platform=="darwin":os.system(f'open "{p}"')
            else:os.system(f'xdg-open "{p}"')
        except Exception as e:messagebox.showerror(APP_TITLE,str(e))
    def on_close(self):
        if self.dirty and not messagebox.askyesno(APP_TITLE,"Есть несохранённые изменения. Закрыть программу?"):return
        self.save_glossary(); self.save_settings(); self.destroy()

if __name__=="__main__":App().mainloop()
